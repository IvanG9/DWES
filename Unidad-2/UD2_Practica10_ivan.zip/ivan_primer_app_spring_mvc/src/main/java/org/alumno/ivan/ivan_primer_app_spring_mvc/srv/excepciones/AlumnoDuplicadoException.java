package org.alumno.ivan.ivan_primer_app_spring_mvc.srv.excepciones;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.dto.AlumnoEdit;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.Alumno;

public class AlumnoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Alumno alumnoExistente;
	private AlumnoEdit alumnoNuevo;
	
	public AlumnoDuplicadoException(Alumno alumnoExistente, AlumnoEdit alumnoEdit) {
		super();
		this.alumnoExistente = alumnoExistente;
		this.alumnoNuevo = alumnoEdit;
	}

	@Override
	public String toString() {
		return "ERROR insertando Alumno: <br>"
				+ "Alumno existente:<br>"
				+ "dni: "+alumnoExistente.getDni()+"<br>"
				+ "nombre: "+alumnoExistente.getNombre()+"<br>"
				+ "Alumno nuevo: <br>"
				+ "dni: "+alumnoNuevo.getDni()+"<br>"
				+ "nombre: "+alumnoNuevo.getNombre();
	}
	
	
	
}