package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import javax.validation.Valid;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.FiltroModulo;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.Modulo;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.NuevoAlumnoModulo;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.AlumnoService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.ModuloService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.excepciones.ModuloDuplicadoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ModuloController {
	Pagina paginaActual = new Pagina("Modulos", "list-modulo");
	@Autowired ModuloService moduloService;
	@Autowired PaginaService paginaServ;
	@Autowired AlumnoService alumnoService;
	
	@RequestMapping(value="list-modulo",method = RequestMethod.GET)
	public String listarModulos(ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.addAttribute("modulos", moduloService.listaModulos());
		model.addAttribute("modulo", new Modulo(0, "Nuevo Modulo", 8, "DAW"));
		model.addAttribute("filtroModulo", new FiltroModulo());
		return "list-modulo";
	}

	@RequestMapping(value="add-modulo",method = RequestMethod.POST)
	public String addModulo(Modulo modulo, ModelMap model) {
		String errores = "";
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		try {
			moduloService.addModulo(modulo);
			model.clear();
			return "redirect:list-modulo";
		} catch (ModuloDuplicadoException e) {
			errores=e.toString();
			model.addAttribute("errores", errores);
			model.addAttribute("modulos", moduloService.listaModulos());
			model.addAttribute("modulo", new Modulo(0, "Nuevo Modulo", 8, "DAW"));
			return "list-modulo";
		}
	}
	
	@RequestMapping(value="del-modulo",method = RequestMethod.GET)
	public String eliminarModulo(@RequestParam String id ,ModelMap model) {
		int idEnv;
		idEnv = Integer.parseInt(id);
		Modulo moduloBorrar = moduloService.encontrarModuloPorId(idEnv);
		moduloService.delModulo(moduloBorrar);
		model.clear();
		return "redirect:list-modulo";
	}
	
	@RequestMapping(value="sort-modulo", method= RequestMethod.GET)
	public String moduloOrdenado(@RequestParam String orden, ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.addAttribute("modulos", moduloService.listaModulos(orden));
		model.addAttribute("modulo", new Modulo(0, "Nuevo Modulo", 8, "DAW"));
		model.addAttribute("filtroModulo", new FiltroModulo());
		return "list-modulo";
	}
	
	@ModelAttribute("listaFiltro")
	public Object[] getmoduloLista() {
		return moduloService.listaFiltro().toArray();
	}
	
	@RequestMapping(value="filt-modulo", method= RequestMethod.POST)
	public String moduloFiltrado(ModelMap model, @Valid FiltroModulo filtroModulo, BindingResult validacion) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.put("filtroModulo", filtroModulo);
		model.addAttribute("modulo", new Modulo(0, "Nuevo Modulo", 8, "DAW"));
		if (validacion.hasErrors()) {
			model.put("modulos", moduloService.listaModulos());
		} else {
			model.put("modulos", moduloService.filtroModulos(filtroModulo));
			
		}
		return "list-modulo";
	}
	
	@RequestMapping(value="matriculados-modulo", method= RequestMethod.GET)
	public String matriculaModulo(@RequestParam String id, ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		int idEnv = Integer.parseInt(id);
		model.addAttribute("modulo", moduloService.encontrarModuloPorId(idEnv));
		model.addAttribute("alumnosM", alumnoService.alumnoMatriculadoEn(idEnv));
		model.addAttribute("alumnosNM", alumnoService.alumnoNoMatriculadoEn(idEnv));
		model.addAttribute("nuevoAlumnoModulo", new NuevoAlumnoModulo());
		return "matriculado-alumno";
	}
	
	@RequestMapping(value="del-alumnoM", method= RequestMethod.GET)
	public String eliminarMatricula(@RequestParam String dni, @RequestParam String id, ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		int idEnv = Integer.parseInt(id);
		alumnoService.eliminarMatricula(dni, idEnv);
		model.clear();
		model.addAttribute("id", id);
		return "redirect:matriculados-modulo";
	}
	
	@RequestMapping(value="add-alumnoNM", method= RequestMethod.POST)
	public String addAlumnoNM(ModelMap model, @Valid NuevoAlumnoModulo nuevoAlumnoModulo, BindingResult validacion) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		if(validacion.hasErrors()) {
			model.addAttribute("id", nuevoAlumnoModulo.getId());
		} else {
			model.addAttribute("id", nuevoAlumnoModulo.getId());
			alumnoService.addMatricula(nuevoAlumnoModulo);
		}
		return "redirect:matriculados-modulo";
	}
}
