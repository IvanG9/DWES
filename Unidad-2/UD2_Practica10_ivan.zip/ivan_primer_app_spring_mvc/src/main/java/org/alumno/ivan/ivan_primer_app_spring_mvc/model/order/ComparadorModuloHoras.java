package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;

import java.util.Comparator;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.Modulo;

public class ComparadorModuloHoras implements Comparator<Modulo> {
	@Override
	public int compare(Modulo a1, Modulo a2) {
		return a1.getHoras() - a2.getHoras();
	}
}