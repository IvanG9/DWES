package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.Date;
import java.util.ArrayList;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.ram.Usuario;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
	
	private static ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
	
	static {
		usuarios.add(new Usuario("IvanPe", "ivanp", "miPassword@1"));
		usuarios.add(new Usuario("JoseRa", "joseramon", "miPassword@1"));
	}
	
	public Usuario encontrarUsuarioPorNickName(String nickname) {
		Usuario usuarioExistente = null;
		for (int i = 0; i < usuarios.size(); i++) {
			if (usuarios.get(i).getNickname().equals(nickname)) {
				return usuarios.get(i);
			}
		}
		return usuarioExistente;
	}
	
	public boolean usuarioValido (Usuario usuarioLogin) {
		Usuario  usuarioEncontrado = encontrarUsuarioPorNickName(usuarioLogin.getNickname());
		if(usuarioEncontrado == null) {
			return false;
		} else {
			if (usuarioLogin.getPassword().contentEquals(usuarioEncontrado.getPassword())) {
				return true;
			}
		}
		return false;
	}
	
	public void modificaUsuario (Usuario usuarioAModificar, String quienModifica) {
		Usuario usuarioActual = encontrarUsuarioPorNickName(quienModifica);
		usuarios.remove(usuarioActual);
		usuarioAModificar.setUser(quienModifica);
		usuarioAModificar.setTs(new Date());
		usuarios.add(usuarioAModificar);
}
}