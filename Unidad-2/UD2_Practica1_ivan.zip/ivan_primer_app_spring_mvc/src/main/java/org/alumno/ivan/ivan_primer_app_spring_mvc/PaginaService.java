package org.alumno.ivan.ivan_primer_app_spring_mvc;

public class PaginaService{

	public void setPagina(Pagina paginaLogin) {
		// TODO Auto-generated method stub
		
	}

	public Object getPagina() {
		// TODO Auto-generated method stub
		return null;
	}


	
	
	
}