package org.alumno.ivan.ivan_primer_app_spring_mvc;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.alumno.ivan.ivan_primer_app_spring_mvc.*;
import org.alumno.ivan.ivan_primer_app_spring_mvc.springmvc.LoginService;

@WebServlet(urlPatterns = "/login.do")

public class LoginServlet extends HttpServlet {
	
	LoginService servicio = new LoginService();
	LogErrorService logErroresServicio = new LogErrorService();
	PaginaService paginaServicio = new PaginaService();
	static Pagina paginaLogin = new Pagina("Login","login.do");
	
	
	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		paginaServicio.setPagina(paginaLogin);
		request.getSession().setAttribute("pagina", new Pagina("login", "login.do"));
		request.getRequestDispatcher("WEB-INF/views/login.jsp").forward(request, response);
		
	}

    @Override
        protected void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	String nombre = request.getParameter("nombre");
    	String password = request.getParameter("password");
    	//paginaServicio.setPagina(paginaLogin);
    	//request.getSession().setAttribute("pagina",paginaServicio.getPagina());
    	request.getSession().setAttribute("pagina",paginaLogin);
    	request.getSession().setAttribute("numModulosInsertados",0);
    	if (servicio.usuarioValido(nombre,password)) {
    			request.getSession().setAttribute("nombre", nombre);
    			request.getRequestDispatcher("WEB-INF/views/bienvenida.jsp").forward(request, response);
    			//response.sendRedirect("list-alumno.do");
    			
    		}else {
    			request.setAttribute("nombre", nombre);
    			logErroresServicio.addLogError("Login incorrecto","Login incorrecto de "+nombre);
    			request.setAttribute("errores", "Usuario " +nombre+ " o contraseña incorrecto");
    			request.getRequestDispatcher("WEB-INF/views/login.jsp").forward(request, response);
    		}
 
    		
    		
		}


}