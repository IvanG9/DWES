package org.alumno.ivan.ivan_primer_app_spring_mvc;

import java.util.Comparator;
import org.alumno.ivan.ivan_primer_app_spring_mvc.*;


public class ComparadorLogErrorExplicacion implements Comparator<LogError>{
	@Override
	public int compare (LogError a1, LogError a2) {

			return a1.getExplicacion().compareTo(a2.getExplicacion());
		
	}
}	