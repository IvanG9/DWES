package org.alumno.ivan.ivan_primer_app_spring_mvc.springmvc;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

	public boolean usuarioValido (String usuario, String password) {
		
		if (usuario.contentEquals("ivan") && password.contentEquals("ivan")){
			return true;
		}
		return false;	
	}
	
}
