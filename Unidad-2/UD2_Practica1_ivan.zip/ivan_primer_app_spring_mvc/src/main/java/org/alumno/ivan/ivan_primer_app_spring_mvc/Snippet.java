package org.alumno.ivan.ivan_primer_app_spring_mvc;

public class Snippet {
	public static void main(String[] args) {
		
	}
}

