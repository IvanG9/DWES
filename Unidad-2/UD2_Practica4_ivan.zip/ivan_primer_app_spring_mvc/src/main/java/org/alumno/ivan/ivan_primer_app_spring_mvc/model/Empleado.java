package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

import java.util.Objects;

import javax.validation.constraints.Size;

import java.io.Serializable;

public class Empleado implements Serializable, Comparable<Empleado> {
	
		private static final long serialVersionUID = 1L;
		@Size(min=9,message="El dni debe de tener un tamaño minimo de 9")
	  	private String dni;
	  	@Size(min=5,message="El nombre debe de tener un tamaño minimo de 5")
	    private String nombre;
	    private String departamento;
	    
	    
		public  String getDni() {
			return dni;
		}
		public void setDni(String dni) {
			this.dni = dni;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getDepartamento() {
			return departamento;
		}
		public void setDepartamento(String departamento) {
			this.departamento = departamento;
		}
		
		public Empleado() {
			
		}
		
		public Empleado(String dni) {
			super();
			this.dni = dni;
		}
		
		
		public Empleado(String dni, String nombre,String departamento ) {
			super();
			this.dni = dni;
			this.nombre = nombre;
			this.departamento = departamento;
;
		}
		
		@Override
		public int hashCode() {
			return Objects.hash(dni);
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Empleado other = (Empleado) obj;
			return Objects.equals(dni, other.dni);
		}
	
		@Override
	    public int compareTo(Empleado Empleado) { 
	        return nombre.compareTo(Empleado.getNombre());
	    }
	    
	
}
