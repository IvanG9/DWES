package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.DepartamentoDuplicadoException;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Departamento;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.DepartamentoService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class DepartamentoController {
	
	
	  Pagina pagina = new Pagina("Departamentos","list-departamento");
		@Autowired
		DepartamentoService departamentoService;
		@Autowired
		PaginaService paginaService;
		
		@RequestMapping(value="list-departamento", method = RequestMethod.GET)
		public String l(ModelMap model) {
			paginaService.setPagina(pagina);
			
			model.addAttribute("departamentos",departamentoService.listaDepartamentos());
			model.addAttribute("pagina",paginaService.getPagina());
			model.addAttribute("departamento",new Departamento());
			return "list-departamento";
		}
		
		@RequestMapping(value="list-departamento-ordenado", method = RequestMethod.GET)
		public String listarDepartamentoOrdenado(ModelMap model,@RequestParam String orden) {
			paginaService.setPagina(pagina);
			String ordenVacio = "";
			ordenVacio+=orden;
			model.addAttribute("departamentos",departamentoService.listaDepartamentos(ordenVacio));
			model.addAttribute("pagina",paginaService.getPagina());
			model.addAttribute("departamento",new Departamento());
			return "list-departamento";
		}
		
		
		@RequestMapping(value="add-departamento", method = RequestMethod.GET) public String mostraEmpleado(ModelMap model){
			
			paginaService.setPagina(pagina);
			model.addAttribute("pagina",paginaService.getPagina());
			model.addAttribute("departamento",new Departamento());
			return "add-departamento";
			
		}
		
		@RequestMapping(value="add-departamento", method = RequestMethod.POST) public String addDepartamento(ModelMap model ,
				Departamento departamento) {
			
			String errores="";
			
			try {
				departamentoService.addDepartamento(departamento);
				
				model.clear();
				
				return "redirect:list-departamento";
			
			} catch (DepartamentoDuplicadoException e){
				errores = e.toString();
			}
			
			model.addAttribute("errores",errores);
			model.addAttribute("departamentos",departamentoService.listaDepartamentos());
			return "list-departamento";

		}
		
		@RequestMapping(value="del-departamento",method = RequestMethod.GET) public String delDepartamento(ModelMap model, @RequestParam String id) {
			
			departamentoService.delDepartamento(new Departamento (Integer.parseInt(id)));
			model.clear();
			return "redirect:list-departamento";
			
		}
	
}