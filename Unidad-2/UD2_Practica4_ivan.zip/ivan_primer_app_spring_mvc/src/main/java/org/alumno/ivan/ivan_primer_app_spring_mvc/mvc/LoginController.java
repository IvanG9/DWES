package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LogErrorService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("nombre")
	public class LoginController {
	@Autowired
	LoginService loginService;
	@Autowired
	LogErrorService logErrorService;
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String mostrarLogin() {
		return "login";
	}
	

	@RequestMapping(value="/", method = RequestMethod.GET)
	public String mostrarLoginMain() {
		return "login";
	}
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String procesaLogin(@RequestParam String nombre,@RequestParam String password,ModelMap model) {
		
		if( !loginService.usuarioValido(nombre, password)){
			model.put("errores", "Usuario : "+nombre+ " o contraseña incorrectos");
			logErrorService.addLogError("Login", "Login incorrecto de "+ nombre);
			return "login";
		}
		System.out.println("Nombre = "+ nombre+" Password = "+ password);
		model.put("nombre", nombre);
		model.put("password", password);
		return "bienvenida";
		
		
	}
	
	@RequestMapping(value="logout", method = RequestMethod.GET)
	public String Logout() {
		return "login";
	}
	
	@RequestMapping(value="bienvenida", method = RequestMethod.GET)
	public String Bienvenida() {
		return "bienvenida";
	}
	
}