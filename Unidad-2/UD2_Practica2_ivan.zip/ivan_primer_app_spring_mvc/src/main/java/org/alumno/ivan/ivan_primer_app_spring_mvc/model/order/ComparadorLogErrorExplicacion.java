package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;

import java.util.Comparator;
import org.alumno.ivan.ivan_primer_app_spring_mvc.*;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.LogError;


public class ComparadorLogErrorExplicacion implements Comparator<LogError>{
	@Override
	public int compare (LogError a1, LogError a2) {

			return a1.getExplicacion().compareTo(a2.getExplicacion());
		
	}
}	