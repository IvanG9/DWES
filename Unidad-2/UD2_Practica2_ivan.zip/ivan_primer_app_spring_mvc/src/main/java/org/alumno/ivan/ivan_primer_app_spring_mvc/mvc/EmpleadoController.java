package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.*;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.*;
import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.*;
@Controller

public class EmpleadoController {
	
    Pagina pagina = new Pagina("Empleados","list-empleado");
	@Autowired
	EmpleadoServicio empleadoService;
	@Autowired
	PaginaService paginaService;
	
	@RequestMapping(value="list-empleado", method = RequestMethod.GET)
	public String listarEmpleados(ModelMap model) {
		paginaService.setPagina(pagina);
		model.addAttribute("empleados",empleadoService.listaEmpleados());
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleado",new Empleado());
		return "list-empleado";
	}
	
	@RequestMapping(value="add-empleado", method = RequestMethod.GET) public String mostraEmpleado(ModelMap model){
	
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		return "add-empleado";
		
	}
	
	@RequestMapping(value="add-empleado", method = RequestMethod.POST) public String addEmpleado(ModelMap model ,
			Empleado empleado) {
		
		String errores="";
		
		try {
			empleadoService.addEmpleado(empleado);
			
			model.clear();
			
			return "redirect:list-empleado";
		
		} catch (EmpleadoDuplicadoException e){
			errores = e.toString();
		}
		
		model.addAttribute("errores",errores);
		model.addAttribute("empleados",empleadoService.listaEmpleados());
		return "list-empleado";

	}
	
	@RequestMapping(value="del-empleado",method = RequestMethod.GET) public String delEmpleado(ModelMap model, @RequestParam String dni) {
		
		empleadoService.delEmpleado(new Empleado (dni));
		model.clear();
		return "redirect:list-empleado";
		
	}


}