package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.EmpleadoDuplicadoException;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Departamento;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.DepartamentoService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.EmpleadoServicio;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class EmpleadoController {
	
    Pagina pagina = new Pagina("Empleados","list-empleado");
	@Autowired
	EmpleadoServicio empleadoService;
	@Autowired
	PaginaService paginaService;
	@Autowired
	DepartamentoService departamentoService;
	
	@RequestMapping(value="list-empleado", method = RequestMethod.GET)
	public String listarEmpleados(ModelMap model) {
		paginaService.setPagina(pagina);
		model.addAttribute("empleados",empleadoService.listaEmpleados());
		model.addAttribute("departamentos",departamentoService.listaDepartamentos());
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleado",new Empleado());
		return "list-empleado";
	}
	
	@RequestMapping(value="list-empleado-ordenado", method = RequestMethod.GET)
	public String listarEmpleadosOrdenados(ModelMap model,@RequestParam String orden) {
		paginaService.setPagina(pagina);
		String ordenVacio = "";
		ordenVacio+=orden;
		model.addAttribute("empleados",empleadoService.listaEmpleados(ordenVacio));
		model.addAttribute("pagina",paginaService.getPagina());
		return "list-empleado";
	}
	
	@RequestMapping(value="add-empleado", method = RequestMethod.GET) public String mostraEmpleado(ModelMap model){
	
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("departamentos",departamentoService.listaDepartamentos());
		model.addAttribute("empleado",new Empleado("","Nuevo alumno",""));
		return "add-empleado";
		
	}
	
	@RequestMapping(value="add-empleado", method = RequestMethod.POST) public String addEmpleado(ModelMap model ,
			Empleado empleado) {
		
		String errores="";
		
		try {
			empleadoService.addEmpleado(empleado);
			
			model.clear();
			
			return "redirect:list-empleado";
		
		} catch (EmpleadoDuplicadoException e){
			errores = e.toString();
			model.addAttribute("errores",errores);
		}
		model.addAttribute("empleados",empleadoService.listaEmpleados());
		return "list-empleado";

	}
	
	@RequestMapping(value="del-empleado",method = RequestMethod.GET) public String delEmpleado(ModelMap model, @RequestParam String dni) {
		
		empleadoService.delEmpleado(new Empleado (dni));
		model.clear();
		return "redirect:list-empleado";
		
	}
	



}