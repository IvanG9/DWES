package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;

import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.DepartamentoDuplicadoException;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Departamento;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorDepartamentoNombre;
import org.springframework.stereotype.Service;

@Service
public class DepartamentoService {

	private static ArrayList<Departamento> departamentos = new ArrayList<Departamento>();

	static {

		departamentos.add(new Departamento(1, "Ingeniero"));
		departamentos.add(new Departamento(2, "Programador"));

	}

	public ArrayList<Departamento> listaDepartamentos() {

		return departamentos;
	}

	public ArrayList<Departamento> listaDepartamentos(String orden) {

		if (orden == null || orden == "") {
			orden = "id";
		}

		switch (orden) {
		case "nombre":
			Collections.sort(departamentos, new ComparadorDepartamentoNombre());
			break;
		case "id":
			Collections.sort(departamentos);
		}

		return departamentos;

	}

	public void addDepartamento(Departamento departamento) throws DepartamentoDuplicadoException {
		try {
			existeDepartamento(departamento);
			departamentos.add(departamento);
		} catch (DepartamentoDuplicadoException e) {
			throw e;
		}
	}

	public void delDepartamento(Departamento departamento) {

		departamentos.remove(departamento);

	}

	public boolean existeDepartamento(Departamento departamento) throws DepartamentoDuplicadoException {
		Departamento departamentoExistente = entontrarDepartamentoPorId(departamento.getId());
		if (departamentoExistente != null) {
			throw new DepartamentoDuplicadoException(departamentoExistente, departamento);
		} else {
			return false;
		}
	}

	public Departamento entontrarDepartamentoPorId(int id) {

		Departamento departamentoDuplicado = null;
		for (int i = 0; i < departamentos.size(); i++) {
			if (departamentos.get(i).getId() == (id)) {
				departamentoDuplicado = departamentos.get(i);
				break;
			}
		}
		return departamentoDuplicado;
	}

}