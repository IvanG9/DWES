package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;


import java.util.Comparator;



import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;

public class ComparadorEmpleadoDepartamentoNombre implements Comparator<Empleado>{
	@Override
	public int compare (Empleado a1, Empleado a2) {
			
			int compararEmpleado = a1.getDepartamento().compareTo(a2.getDepartamento());
			
			if(compararEmpleado != 0) {
				return compararEmpleado;
			}else {
				return a1.getNombre().compareTo(a2.getNombre());
			}
	}
	
}	