package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

import java.util.Objects;

public class LogError implements Comparable<LogError> {
	  
	private static int count = 0; 
	public int id;
	public String tipo;
	public String explicacion;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getExplicacion() {
		return explicacion;
	}

	public void setExplicacion(String explicacion) {
		this.explicacion = explicacion;
	}

	public LogError(String tipo, String explicacion) {
		super();
		this.id = ++count;
		this.tipo = tipo;
		this.explicacion = explicacion;
	}

	@Override
	public int compareTo(LogError error) {
		
		return id-error.getId();
		
	}
	//Nuevos metodos
	
	public LogError() {
		
	}
	
	public LogError(int id) {
		super();
		this.id = id;
	}
	
}

	