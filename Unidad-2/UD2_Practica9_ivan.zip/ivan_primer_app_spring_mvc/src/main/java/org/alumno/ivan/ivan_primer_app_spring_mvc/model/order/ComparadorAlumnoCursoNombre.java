package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;

import java.util.Comparator;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Alumno;

public class ComparadorAlumnoCursoNombre implements Comparator<Alumno> {
	@Override
	public int compare(Alumno a1, Alumno a2) {
		int compCurso = a1.getCurso()-a2.getCurso();
		if (compCurso!=0) {
			return compCurso;
		} else {
			return a1.getNombre().compareTo(a2.getNombre());
		}
	}
}