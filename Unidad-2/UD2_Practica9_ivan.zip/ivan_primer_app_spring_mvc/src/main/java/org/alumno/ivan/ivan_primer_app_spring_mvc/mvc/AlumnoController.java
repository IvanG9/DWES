package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Alumno;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.DocAlumno;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.FiltroAvanzadoAlumno;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Usuario;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.AlumnoService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.FileService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.I18nService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.ModuloService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.excepciones.AlumnoDuplicadoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

@Controller
@SessionAttributes({ "loginNickName", "loginName", "usuario" })
public class AlumnoController {
	Pagina paginaActual = new Pagina("Alumnos", "list-alumno");
	@Autowired
	AlumnoService alumnoService;
	@Autowired
	ModuloService moduloService;
	@Autowired
	PaginaService paginaServ;
	@Autowired
	FileService fileServicio;
	@Autowired
	I18nService i18nService;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "list-alumno", method = RequestMethod.GET)
	public String listarAlumnos(ModelMap model) {
		paginaActual.setIdioma(i18nService.getIdioma());
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.addAttribute("alumnos", alumnoService.listaAlumnos());
		model.addAttribute("filtroAvanzadoAlumno", new FiltroAvanzadoAlumno());
		return "list-alumno";
	}

	@RequestMapping(value = "add-alumno", method = RequestMethod.GET)
	public String mostrarAlumno(ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.addAttribute("alumno", new Alumno("Nuevo Alumno", "", 18, "DAW", 2));
		return "add-alumno";
	}

	@ModelAttribute("interesadoEnLista")
	public Object[] getinteresadoEnLista() {
		return alumnoService.listaInteresadoEn().toArray();
	}

	@ModelAttribute("horarioLista")
	public Object[] gethorarioLista() {
		return alumnoService.listaHorarios().toArray();
	}

	@ModelAttribute("paisLista")
	public HashMap<String, String> getpaisLista() {
		return alumnoService.listaPaises();
	}

	@ModelAttribute("moduloLista")
	public Object[] getmoduloLista() {
		return moduloService.listaModulos().toArray();
	}

	@RequestMapping(value = "add-alumno", method = RequestMethod.POST)
	public String addAlumno(@Valid Alumno alumno, BindingResult validacion, ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		if (validacion.hasErrors()) {
			return "add-alumno";
		}
		String errores = "";
		try {
			alumnoService.addAlumno(alumno);
			model.clear();
			return "redirect:list-alumno";
		} catch (AlumnoDuplicadoException e) {
			errores = e.toString();
			model.addAttribute("errores", errores);
			return "add-alumno";
		}
	}

	@RequestMapping(value = "del-alumno", method = RequestMethod.GET)
	public String eliminarAlumno(@RequestParam String dni, ModelMap model) {
		try {
			Alumno alumnoBorrar = alumnoService.encontrarAlumnoPorDni(dni);
			alumnoService.delAlumno(alumnoBorrar);
			model.clear();
			return "redirect:list-alumno";
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return "redirect:list-alumno";
		}
	}

	@RequestMapping(value = "update-alumno", method = RequestMethod.GET)
	public String alumnoModificar(@RequestParam String dni, ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		Alumno alumnoModificar = alumnoService.encontrarAlumnoPorDni(dni);
		model.addAttribute("alumno", alumnoModificar);
		return "update-alumno";
	}

	@RequestMapping(value = "update-alumno", method = RequestMethod.POST)
	public String alumnoModificado(ModelMap model, @Valid Alumno alumno, BindingResult validacion) {
		if (validacion.hasErrors()) {
			paginaServ.setPagina(paginaActual);
			model.addAttribute("pagina", paginaServ.getPagina());
			return "update-alumno";
		}
		try {
			alumnoService.modificaAlumno(alumno, model.getAttribute("loginNickName").toString());
			model.clear();
			return "redirect:list-alumno";
		} catch (Exception e) {
			paginaServ.setPagina(paginaActual);
			model.addAttribute("pagina", paginaServ.getPagina());
			model.addAttribute("errores", e.getMessage());
			return "update-alumno";
		}
	}

	@RequestMapping(value = "sort-alumno", method = RequestMethod.GET)
	public String alumnoOrdenado(@RequestParam String orden, ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.addAttribute("alumnos", alumnoService.listaAlumnos(orden));
		model.addAttribute("filtroAvanzadoAlumno", new FiltroAvanzadoAlumno());
		return "list-alumno";
	}

	@ModelAttribute("opcionesTipoDoc")
	public Object[] getopcionesTipoDoc() {
		return alumnoService.opcionesTipoDoc().toArray();
	}

	@RequestMapping(value = "docs-alumno", method = RequestMethod.GET)
	public String getDocsAlumno(ModelMap model, @RequestParam String dni) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("alumno", alumnoService.encontrarAlumnoPorDni(dni));
		model.addAttribute("docAlumno", new DocAlumno(alumnoService.siguienteDoc(dni)));
		model.addAttribute("pagina", paginaServ.getPagina());
		return "docs-alumno";
	}

	@RequestMapping(value = "add-docAlumno", method = RequestMethod.POST)
	public String addDocAlumno(ModelMap model, @Valid DocAlumno docAlumno, BindingResult validacion) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		if (validacion.hasErrors()) {
			model.addAttribute("alumno", alumnoService.encontrarAlumnoPorDni(docAlumno.getDni()));
			return "docs-alumno";
		}

		String dni = (String) docAlumno.getDni();
		Alumno alumno = alumnoService.encontrarAlumnoPorDni(dni);

		try {
			if (alumno == null) {
				throw new Exception("Alumno desconocido");
			}
			if (model.getAttribute("loginNickName") == null) {
				throw new Exception("Para añadir documentación debe estar logeado");
			}

			String extension = fileServicio.getExtensionMultipartfile(docAlumno.getFichero());
			String nombreFicheroAGuardar = String.format("%s_idDoc_%s.%s", dni, docAlumno.getId(), extension);

			ArrayList<String> listaErroresAlGuardar = fileServicio.guardaDocumentacionAlumno(docAlumno.getFichero(),
					nombreFicheroAGuardar);
			if (!listaErroresAlGuardar.isEmpty()) {
				String mensajeCompleto = "";
				for (String mensaje : listaErroresAlGuardar) {
					mensajeCompleto += mensaje + "<br>";
				}
				throw new Exception(mensajeCompleto);
			}

			docAlumno.setTipoFichero(extension);
			docAlumno.setContentTypeFicher(docAlumno.getFichero().getContentType());

			alumnoService.addDocAlumno(alumno, docAlumno);
			Usuario usuarioActivo = (Usuario) model.getAttribute("usuario");
			alumnoService.modificaAlumno(alumno, usuarioActivo.getNickname());
			model.addAttribute("alumno", alumnoService.encontrarAlumnoPorDni(docAlumno.getDni()));
			model.addAttribute("docAlumno", new DocAlumno(alumnoService.siguienteDoc(dni)));
			return "docs-alumno";
		} catch (Exception e) {
			model.addAttribute(alumnoService.encontrarAlumnoPorDni(alumno.getDni()));
			model.addAttribute("errores", e.getMessage());
			return "docs-alumno";
		}
	}

	@RequestMapping(value = "/descargar-docAlumno/{dni}/{idDoc}", method = RequestMethod.GET)
	public @ResponseBody void descargarDocAlumno(HttpServletResponse response, @PathVariable("dni") String dni,
			@PathVariable("idDoc") Integer idDoc) throws IOException {
		try {
			Optional<DocAlumno> docAlumno = alumnoService.encontrarDocAlumnoPorDni_IdDoc(dni, idDoc);
			if (docAlumno.isPresent()) {
				String nombreFichero = dni + "_idDoc_" + idDoc + "." + docAlumno.get().getTipoFichero();
				FileSystemResource resource = fileServicio.getDocumentoAlumno(nombreFichero);
				if (!resource.exists()) {
					throw new IOException("El documento con el dni '" + dni + "' y el id '" + idDoc + "' no existe.");
				}
				File fichero = resource.getFile();

				response.setContentType(docAlumno.get().getContentTypeFicher());
				response.setHeader("Content-Disposition", "attachment; filename=" + fichero.length());
				response.setHeader("Content-Length", String.valueOf(fichero.length()));
				InputStream in = new FileInputStream(fichero);
				FileCopyUtils.copy(in, response.getOutputStream());

			} else {
				throw new IOException("El documento con el dni '" + dni + "' y el id '" + idDoc + "' no existe.");
			}

		} catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
	}

	@ModelAttribute("cicloListaAlumnos")
	public List<String> getCicloListaAlumnos() {
		return alumnoService.cicloListaAlumnos();
	}

	@ModelAttribute("dniListaAlumnos")
	public List<String> getDniListaAlumnos() {
		return alumnoService.dniListaAlumnos();
	}

	@ModelAttribute("horarioListaAlumnos")
	public List<String> getHorarioListaAlumnos() {
		return alumnoService.horarioListaAlumnos();
	}

	@RequestMapping(value = "filtro-avanzado-alumno", method = RequestMethod.POST)
	public String filtroAvanzadoAlumno(ModelMap model, @Valid FiltroAvanzadoAlumno filtroAvanzadoAlumno,
			BindingResult validacion) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.put("filtroAvanzadoAlumno", filtroAvanzadoAlumno);
		if (validacion.hasErrors()) {
			model.put("alumnos", alumnoService.listaAlumnos());
		} else {
			model.put("alumnos", alumnoService.filtroAvanzadoAlumnos(filtroAvanzadoAlumno));
		}
		return "list-alumno";
	}

}
