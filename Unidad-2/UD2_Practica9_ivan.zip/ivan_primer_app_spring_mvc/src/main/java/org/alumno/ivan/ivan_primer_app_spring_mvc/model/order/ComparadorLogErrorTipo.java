package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;

import java.util.Comparator;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.LogError;

public class ComparadorLogErrorTipo implements Comparator<LogError> {

	public int compare(LogError e1, LogError e2) {
		return e1.getTipo().compareTo(e2.getTipo());
	}
}