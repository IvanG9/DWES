package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;

import java.util.Comparator;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Alumno;

public class ComparadorAlumnoEdadNombre implements Comparator<Alumno>{
	@Override 
	public int compare(Alumno a1, Alumno a2) {
		int compEdad = a1.getEdad()-a2.getEdad();
		if (compEdad!=0) {
			return compEdad;
		} else {
			return a1.getNombre().compareTo(a2.getNombre());
		}
	}
}