package org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado; 

public class EmpleadoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Empleado empleadoExistente;
	private Empleado empleadoNuevo;
	
	public EmpleadoDuplicadoException(Empleado empleadoExistente, Empleado empleadoNuevo) {
		super();
		this.empleadoExistente = empleadoExistente;
		this.empleadoNuevo = empleadoNuevo;
	}

	@Override
	public String toString() {
		
		return "ERROR insertando Empleado: <br>"
				+ "Empleado existente:<br>"
				+ "Dni: "+empleadoExistente.getDni()+"<br>"
				+ "Nombre: "+empleadoExistente.getNombre()+"<br>"
				+ "Empleado nuevo: <br>"
				+ "Dni: "+empleadoNuevo.getDni()+"<br>"
				+ "Nombre: "+empleadoNuevo.getNombre();
	}
		
	
	
}