package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.ArrayList;

import java.util.Collections;

import org.alumno.ivan.ivan_primer_app_spring_mvc.*;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.LogError;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorLogErrorExplicacion;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorLogErrorTipo;
import org.springframework.stereotype.Service;


@Service
public class LogErrorService {

	private static ArrayList<LogError> errores = new ArrayList<LogError>();

	public ArrayList<LogError> listaErrores() {

		return errores;
	}

	public ArrayList<LogError> listaErrores(String orden) {

		if (orden == null || orden == "") {
			orden = "nombre";
		}

		switch (orden) {
		case "id":
			Collections.sort(errores);
			break;
		case "tipo":
			Collections.sort(errores, new ComparadorLogErrorTipo());
			break;
		case "explicacion":
			Collections.sort(errores, new ComparadorLogErrorExplicacion());
			break;

		}

		return errores;

	}

	public void addLogError(String tipo,String explicacion) {
		errores.add(new LogError(tipo,explicacion));
	}

	public void delError(LogError error) {
		errores.remove(error);
	}


}
