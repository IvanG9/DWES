package org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Departamento;


public class DepartamentoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Departamento departamentoExistente;
	private Departamento departamentoNuevo;
	
	public DepartamentoDuplicadoException(Departamento departamentoExistente, Departamento departamentoNuevo) {
		super();
		this.departamentoExistente = departamentoExistente;
		this.departamentoNuevo = departamentoNuevo;
	}

	@Override
	public String toString() {
		
		return "ERROR insertando Departamento: <br>"
				+ "Departamento existente:<br>"
				+ "Id: "+departamentoExistente.getId()+"<br>"
				+ "Nombre: "+departamentoExistente.getNombre()+"<br>"
				+ "Departamento nuevo: <br>"
				+ "Id: "+departamentoNuevo.getId()+"<br>"
				+ "Nombre: "+departamentoNuevo.getNombre();
	}
	
	
	
}