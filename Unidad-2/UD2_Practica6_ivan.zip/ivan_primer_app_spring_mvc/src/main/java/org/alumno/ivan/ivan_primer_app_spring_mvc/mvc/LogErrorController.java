package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.LogError;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LogErrorService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class LogErrorController {
	
    Pagina pagina = new Pagina("Errores","list-errores");
	@Autowired
	LogErrorService logErrorService;
	@Autowired
	PaginaService paginaService;
	
	@RequestMapping(value="list-error", method = RequestMethod.GET)
	public String listarErrores(ModelMap model) {
		paginaService.setPagina(pagina);
		model.addAttribute("logErrores",logErrorService.listaErrores());
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("logError",new LogError());
		return "list-logError";
	}
	
	@RequestMapping(value="list-error-ordenado", method = RequestMethod.GET)
	public String listarErroresOrdenados(ModelMap model,@RequestParam String orden) {
		paginaService.setPagina(pagina);
		String ordenVacio = "";
		ordenVacio+=orden;
		model.addAttribute("logErrores",logErrorService.listaErrores(ordenVacio));
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("logError",new LogError());
		return "list-logError";
	}

	@RequestMapping(value="del-logError",method = RequestMethod.GET) public String delError(ModelMap model, @RequestParam String id) {
		
		logErrorService.delError(new LogError (Integer.parseInt(id)));
		model.clear();
		return "redirect:list-logError";
		
	}


}