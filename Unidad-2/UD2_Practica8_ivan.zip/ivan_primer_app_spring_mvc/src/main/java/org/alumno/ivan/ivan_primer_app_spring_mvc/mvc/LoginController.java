package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import javax.validation.Valid;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Usuario;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LogErrorService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LoginService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes({"nickname","loginNickName"})

public class LoginController {
	Pagina paginaActual = new Pagina("Home", "login");
	@Autowired LoginService loginService;
	@Autowired LogErrorService logErrorService;
	@Autowired PaginaService paginaServ;
	
	@RequestMapping(value="/",method = RequestMethod.GET)
	public String inicial(ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.put("pagina", paginaServ.getPagina());
		model.put("usuario", new Usuario("", "", ""));
		model.put("loginNickName","Desconocido");
		return "login";
	}
	
	@RequestMapping(value="login",method = RequestMethod.GET)
	public String mostrarLogin(ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.put("pagina", paginaServ.getPagina());
		model.put("usuario", new Usuario("", "", ""));
		model.put("loginNickName","Desconocido");
		return "login";
	}
	
	@RequestMapping(value="login",method = RequestMethod.POST)
	public String procesaLogin(ModelMap model, @Valid Usuario usuario,BindingResult validacion) {
		if(!loginService.usuarioValido(usuario)) {
			model.put("pagina", paginaServ.getPagina());
			model.put("errores", "Usuario '"+usuario.getNickname()+"' o contraseña incorrecta");
			model.put("loginNickName","Desconocido");
			logErrorService.addLogError("Login Incorrecto", "Login incorrecto de '"+usuario.getNickname()+"'");
			return "login";
		}
		paginaServ.setPagina(new Pagina("Bienvenida", "login"));
		model.put("pagina", paginaServ.getPagina());
		model.put("usuario", loginService.encontrarUsuarioPorNickName(usuario.getNickname()));
		model.put("nickname", usuario.getNickname());
		model.put("loginNickName", usuario.getNickname());
		return "bienvenida";
	}
}
