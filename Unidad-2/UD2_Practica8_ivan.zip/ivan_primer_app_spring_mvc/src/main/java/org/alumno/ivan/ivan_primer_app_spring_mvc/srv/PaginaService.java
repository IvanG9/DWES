package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.springframework.stereotype.Service;
@Service
public class PaginaService {
	private static Pagina paginaActual;
	
	public void setPagina (Pagina paginaNueva) {
		paginaActual = paginaNueva;
	}
	
	public Pagina getPagina () {
		return paginaActual;
	}
}