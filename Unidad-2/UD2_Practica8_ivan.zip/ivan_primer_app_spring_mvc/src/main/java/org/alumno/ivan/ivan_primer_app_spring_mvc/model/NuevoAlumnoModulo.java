package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

public class NuevoAlumnoModulo {
	private String dni;
	private String id;
	
	
	public NuevoAlumnoModulo(String dni, String id) {
		super();
		this.dni = dni;
		this.id = id;
	}


	public NuevoAlumnoModulo() {
	}


	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}
	
	
	
}