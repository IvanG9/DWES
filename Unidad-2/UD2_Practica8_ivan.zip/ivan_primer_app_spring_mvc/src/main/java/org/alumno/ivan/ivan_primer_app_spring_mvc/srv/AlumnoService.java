package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.ArrayList;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Alumno;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.DocAlumno;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.FiltroAvanzadoAlumno;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.NuevoAlumnoModulo;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorAlumnoCicloNombre;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorAlumnoCursoNombre;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorAlumnoDni;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorAlumnoEdadNombre;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.excepciones.AlumnoDuplicadoException;
import org.springframework.stereotype.Service;

@Service
public class AlumnoService {
	private static ArrayList<Alumno> alumnos = new ArrayList<Alumno>();
	
	static {
		ArrayList<Integer> listaMatriculadoEn1 = new ArrayList<Integer>();
		ArrayList<Integer> listaMatriculadoEn2 = new ArrayList<Integer>();
		listaMatriculadoEn1.add(1);
		listaMatriculadoEn2.add(1);
		listaMatriculadoEn2.add(2);
		alumnos.add(new Alumno("Jose", "12345678T", 20, "DAW", 2, listaMatriculadoEn1));
		alumnos.add(new Alumno("Pedro", "12345677P", 19, "DAM", 1, listaMatriculadoEn1));
		alumnos.add(new Alumno("Juan", "12345667U", 18, "DAM", 1, listaMatriculadoEn2));
		alumnos.add(new Alumno("Maria", "12345567L", 21, "DAM", 2, listaMatriculadoEn2));
	}
	
	public ArrayList<Alumno> listaAlumnos(){
		return alumnos;
	}
	
	public void addAlumno(Alumno alumno) throws AlumnoDuplicadoException{
		try {
			existeAlumno(alumno);
			alumnos.add(alumno);
		}catch(AlumnoDuplicadoException e) {
			throw e;
		}
	}
	
	public void delAlumno(Alumno alumno) {
		alumnos.remove(alumno);
	}
	
	public boolean existeAlumno(Alumno alumno) throws AlumnoDuplicadoException{
		Alumno alumnoExistente = encontrarAlumnoPorDni(alumno.getDni());
		if(alumnoExistente!=null) {
			throw new AlumnoDuplicadoException(alumnoExistente, alumno);
		} else {
			return false;
		}
	}
	
	public Alumno encontrarAlumnoPorDni(String dni){
		Optional<Alumno> alumnoDuplicado = null;
		
		alumnoDuplicado = alumnos.stream().filter(a->a.getDni().equals(dni)).findFirst();
		if (alumnoDuplicado.isPresent()) {
			return alumnoDuplicado.get();
		} else {
			return null;
		}
	}
	
	public void modificaAlumno (Alumno alumnoModificado, String usuarioModificacion) throws Exception {
		if (alumnoModificado == null || usuarioModificacion.equals("")) {
			throw new Exception("No se encuentran los datos del alumno o del usuaio de modificacion");
		} else {
			Alumno alumnoActual = encontrarAlumnoPorDni(alumnoModificado.getDni());
			if (alumnoActual.sePuedeModificarUtilizando(alumnoModificado)) {
				alumnos.remove(alumnoActual);
				alumnoModificado.setDocsAlumno(alumnoActual.getDocsAlumno());
				alumnoModificado.setUser(usuarioModificacion);
				alumnoModificado.setTs(new Date());
				alumnos.add(alumnoModificado);
			} else {
				throw new Exception(alumnoActual.mensajeNoSePuedeModificar());
			}
		}
	}
	
	public List<Alumno> listaAlumnos(String criterioOrdenacion) {
		if(criterioOrdenacion.equals("nombre")) {
			Collections.sort(alumnos);
			return alumnos;
		}
		if(criterioOrdenacion.equals("dni")) {
			Collections.sort(alumnos, new ComparadorAlumnoDni());
			return alumnos;
		}
		if(criterioOrdenacion.equals("edadNombre")) {
			Collections.sort(alumnos, new ComparadorAlumnoEdadNombre());
			return alumnos;
		}
		if(criterioOrdenacion.equals("cicloNombre")) {
			Collections.sort(alumnos, new ComparadorAlumnoCicloNombre());
			return alumnos;
		}
		if(criterioOrdenacion.equals("cursoNombre")) {
			Collections.sort(alumnos, new ComparadorAlumnoCursoNombre());
			return alumnos;
		}
		return alumnos;
	}
	
	public List<String> listaInteresadoEn() {
		ArrayList<String> listaInteresadoEn = new ArrayList<String>();
		listaInteresadoEn.add("Backend");
		listaInteresadoEn.add("Frontend");
		return listaInteresadoEn;
	}
	
	public List<String> listaHorarios() {
		ArrayList<String> listaHorarios = new ArrayList<String>();
		listaHorarios.add("Manyana");
		listaHorarios.add("Tarde");
		return listaHorarios;
	}
	
	public HashMap <String, String> listaPaises() {
		HashMap<String,String> listaPaises = new HashMap<String,String>();
		listaPaises.put("ES", "España");
		return listaPaises;
	}
	
	public List<String> opcionesTipoDoc() {
		List<String> opcionesTipoDoc = new ArrayList<String>();
		opcionesTipoDoc.add("Certificado");
		opcionesTipoDoc.add("Justificante");
		opcionesTipoDoc.add("Solicitud");
		return opcionesTipoDoc;
	}
	
	public int siguienteDoc(String dni) {
		Alumno alumnoEncontrado = encontrarAlumnoPorDni(dni);
		if(alumnoEncontrado.getDocsAlumno() == null){
			return 1;
		} else {
			return alumnoEncontrado.getDocsAlumno().size()+1;
		}
	}
	
	public void addDocAlumno (Alumno alumno, DocAlumno docAlumno) {
		ArrayList<DocAlumno> nuevaLista = alumno.getDocsAlumno();
		if (nuevaLista == null) {
			nuevaLista = new ArrayList<DocAlumno>();
		}
		nuevaLista.add(docAlumno);
		alumno.setDocsAlumno(nuevaLista);
	}
	

	public List<String> cicloListaAlumnos() {
		Set<String> listaSinRepeticiones=alumnos.stream().filter(a->a.getCiclo()!=null).map(a->a.getCiclo()).collect(Collectors.toSet());
		return listaSinRepeticiones.stream().sorted().collect(Collectors.toList());
	}
	
	public List<String> dniListaAlumnos() {
		Set<String> listaSinRepeticiones=alumnos.stream().filter(a->a.getDni()!=null).map(a->a.getDni()).collect(Collectors.toSet());
		return listaSinRepeticiones.stream().sorted().collect(Collectors.toList());
	}
	
	public List<String> horarioListaAlumnos() {
		Set<String> listaSinRepeticiones=alumnos.stream().filter(a->a.getHorario()!=null).map(a->a.getHorario()).collect(Collectors.toSet());
		return listaSinRepeticiones.stream().sorted().collect(Collectors.toList());
	}
	
	public List<Alumno> filtroAvanzadoAlumnos(FiltroAvanzadoAlumno filtroAvanzadoAlumno) {
		List<Alumno> lista = alumnos;
		try {
			if (!"-".equals(filtroAvanzadoAlumno.getDni())) {
				lista=lista.stream().filter(a->a.getDni()!=null && a.getDni().equals(filtroAvanzadoAlumno.getDni())).collect(Collectors.toList());
			}
			if (!"-".equals(filtroAvanzadoAlumno.getCiclo())) {
				lista=lista.stream().filter(a->a.getCiclo()!=null && a.getCiclo().equals(filtroAvanzadoAlumno.getCiclo())).collect(Collectors.toList());
			}
			if (!"-".equals(filtroAvanzadoAlumno.getHorario())) {
				lista=lista.stream().filter(a->a.getHorario()!=null && a.getHorario().equals(filtroAvanzadoAlumno.getHorario())).collect(Collectors.toList());
			}
		} catch (Exception e) {
			lista = new ArrayList<Alumno>();
		}
		
		if (lista == null) return new ArrayList<Alumno>();
		return lista;
	}
	
	public List<Alumno> alumnoMatriculadoEn(int id) {
		List<Alumno> matriculados = new ArrayList<Alumno>();
		for(int i = 0; i < alumnos.size(); i++) {
			for(int j = 0; j < alumnos.get(i).getMatriculadoEn().size(); j++) {
				if (alumnos.get(i).getMatriculadoEn().get(j) == id) {
					matriculados.add(alumnos.get(i));
					break;
				}
			}
		}
		return matriculados;
	}
	
	public HashMap<String, String> alumnoNoMatriculadoEn(int id) {
		HashMap<String, String> noMatriculados = new HashMap<String, String>();
		boolean esta;
		for(int i = 0; i < alumnos.size(); i++) {
			esta = false;
			for(int j = 0; j < alumnos.get(i).getMatriculadoEn().size(); j++) {
				if (alumnos.get(i).getMatriculadoEn().get(j) == id) {
					esta = true;
					break;
				}
			}
			if (!esta) {
				noMatriculados.put(alumnos.get(i).getDni(), alumnos.get(i).getNombre());
			}
		}
		return noMatriculados;
	}
	
	public void eliminarMatricula(String dni, int id) {
		Alumno alumnoEnc = encontrarAlumnoPorDni(dni);
		ArrayList<Integer> nuevaLista = new ArrayList<Integer>();
		for (int i = 0; i < alumnoEnc.getMatriculadoEn().size(); i++) {
			if (alumnoEnc.getMatriculadoEn().get(i) != id) {
				nuevaLista.add(alumnoEnc.getMatriculadoEn().get(i));
			}
		}
		alumnoEnc.setMatriculadoEn(nuevaLista);
	}
	
	
	public void addMatricula(NuevoAlumnoModulo nuevoAl) {
		Alumno alumno = encontrarAlumnoPorDni(nuevoAl.getDni());
		int id = Integer.parseInt(nuevoAl.getId());
		ArrayList<Integer> lista = new ArrayList<Integer>();
		lista = alumno.getMatriculadoEn();
		lista.add(id);
		alumno.setMatriculadoEn(lista);
	}
	
	public Optional<DocAlumno> encontrarDocAlumnoPorDni_IdDoc(String dni, Integer idDoc) {
		Alumno alumnoEnc = encontrarAlumnoPorDni(dni);
		ArrayList<DocAlumno> docsAlumnoEnc = alumnoEnc.getDocsAlumno();
		return docsAlumnoEnc.stream().filter(d -> d.getId() == idDoc).findFirst();		
	}
	
}