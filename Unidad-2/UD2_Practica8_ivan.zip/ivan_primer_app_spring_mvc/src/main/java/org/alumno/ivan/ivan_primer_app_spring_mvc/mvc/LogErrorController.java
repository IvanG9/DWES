package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.LogError;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LogErrorService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LogErrorController {
	Pagina paginaActual = new Pagina("Errores", "list-error");
	@Autowired LogErrorService logErrorService;
	@Autowired PaginaService paginaServ;
	
	@RequestMapping(value="list-error",method = RequestMethod.GET)
	public String listarErrores(ModelMap model) {
		paginaServ.setPagina(paginaActual);
		model.addAttribute("pagina", paginaServ.getPagina());
		model.addAttribute("errores", logErrorService.listaErrores());
		return "list-error";
	}

	@RequestMapping(value="del-error",method = RequestMethod.GET)
	public String eliminarError(@RequestParam String id ,ModelMap model) {
		int idEnv;
		idEnv = Integer.parseInt(id);
		LogError errorBorrar = logErrorService.encontrarLogErrorPorId(idEnv);
		logErrorService.delLogError(errorBorrar);
		model.clear();
		return "redirect:list-error";
	}
}
