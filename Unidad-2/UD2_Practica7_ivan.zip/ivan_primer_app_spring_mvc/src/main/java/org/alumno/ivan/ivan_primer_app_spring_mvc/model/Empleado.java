package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

import java.util.Objects;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.alumne.ivan.ivan_primer_app_spring_mvc.util.Ts;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.interfaces.Modificable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Empleado implements Serializable, Comparable<Empleado>, Modificable<Empleado> {

	private static final long serialVersionUID = 1L;
	@Pattern(regexp = "[0-9]{8}[A-Za-z]{1}", message = "El dni debe tener 8 numeros y una letra")
	private String dni;
	@Size(min = 5, message = "El nombre debe de tener un tamaño minimo de 5")
	private String nombre;
	private String departamento;
	private Date ts;
	private String user;
	private boolean practicas;
	private String[] interesadosEn;
	private String lenguajeFavorito;
	private String genero;
	private String horario;
	private String pais;
	private String hobbies;
	private ArrayList<DocEmpleado> docsEmpleado;

	public boolean isPracticas() {
		return practicas;
	}

	public String getPracticas() {

		if (practicas == true) {
			return "<input type=\"checkbox\" checked onclick=\"return false;\"";
		} else {
			return "<input type=\"checkbox\" disable onclick=\"return false;\"";
		}

	}

	public void setPracticas(boolean practicas) {
		this.practicas = practicas;
	}

	public String[] getInteresadosEn() {
		return interesadosEn;
	}

	public void setInteresadosEn(String[] interesadosEn) {
		this.interesadosEn = interesadosEn;
	}

	public String getLenguajeFavorito() {
		return lenguajeFavorito;
	}

	public void setLenguajeFavorito(String lenguajeFavorito) {
		this.lenguajeFavorito = lenguajeFavorito;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	
	public String getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}

	public Date getTs() {
		return ts;
	}

	public void setTs(Date ts) {
		this.ts = ts;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Empleado() {

	}

	public Empleado(String dni) {
		super();
		this.dni = dni;
	}

	public Empleado(String dni, String nombre, String departamento) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.departamento = departamento;
		this.practicas = false;
		this.horario = "Mañana";

	}

	public ArrayList<DocEmpleado> getDocsEmpleado() {
		return docsEmpleado;
	}

	public void setDocsEmpleado(ArrayList<DocEmpleado> docsEmpleado) {
		this.docsEmpleado = docsEmpleado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return Objects.equals(dni, other.dni);
	}

	@Override
	public int compareTo(Empleado Empleado) {
		return nombre.compareTo(Empleado.getNombre());
	}

	@Override
	public boolean sePuedeModificarUtilizando(Empleado itemModificao) {
		if (this.getUser() != null && this.getTs() != null) {

			String usuarioActual = this.getUser();
			String usuarioModificado = itemModificao.getUser();
			Date fechaActual = Ts.parseIso(Ts.formatIso(this.getTs()));
			Date fechaModificado = Ts.parseIso(Ts.formatIso(itemModificao.getTs()));

			if (!usuarioActual.equals(usuarioModificado) || !fechaActual.equals(fechaModificado)) {
				return false;
			}
		}
		return true;
	}

	public String mensajeNoSePuedeModificar() {
		String msg = "\r\n\t[Error]\r\n<br/>" + "\t '$item' ha sido modificado por otro usuario.\r\n<br/>"
				+ "\t Para evitar la perdida de informacion se impide guardar '$item'. \r\n<br/>"
				+ "\t Ultima modificacion realizzada por [" + this.getUser() + "] el [" + Ts.ts(this.getTs())
				+ "]\r\n<br/>";

		return msg.replace("$item", "Alumno");
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	

	
}
