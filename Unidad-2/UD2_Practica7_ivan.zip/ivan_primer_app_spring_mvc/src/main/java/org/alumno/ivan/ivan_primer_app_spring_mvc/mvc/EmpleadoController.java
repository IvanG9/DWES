package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.HashMap;

import javax.validation.Valid;

import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.EmpleadoDuplicadoException;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.DocEmpleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.FiltroEmpleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.FiltroEmpleadoAvanzado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.DepartamentoService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.EmpleadoServicio;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("nickname")
public class EmpleadoController {
	
    Pagina pagina = new Pagina("Empleados","list-empleado");
	@Autowired
	EmpleadoServicio empleadoService;
	@Autowired
	PaginaService paginaService;
	@Autowired
	DepartamentoService departamentoService;
	
	@InitBinder
	protected void initBinder (WebDataBinder binder) {
		SimpleDateFormat dateFormat= new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,true));
	}
	
	
	@RequestMapping(value="list-empleado", method = RequestMethod.GET)
	public String listarEmpleados(ModelMap model) {
		paginaService.setPagina(pagina);
		model.addAttribute("empleados",empleadoService.listaEmpleados());
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleado",new Empleado());
		model.addAttribute("filtroempleado",new FiltroEmpleado());
		model.addAttribute("filtroempleadoavanzado",new FiltroEmpleadoAvanzado());

		return "list-empleado";
	}
	
	@RequestMapping(value="list-empleado-ordenado", method = RequestMethod.GET)
	public String listarEmpleadosOrdenados(ModelMap model,@RequestParam String orden) {
		paginaService.setPagina(pagina);
		String ordenVacio = "";
		ordenVacio+=orden;
		model.addAttribute("empleados",empleadoService.listaEmpleados(ordenVacio));
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleado",new Empleado());
		model.addAttribute("filtroempleado",new FiltroEmpleado());
		model.addAttribute("filtroempleadoavanzado",new FiltroEmpleadoAvanzado());

		return "list-empleado";
	}
	
	@RequestMapping(value="add-empleado", method = RequestMethod.GET) public String mostraEmpleado(ModelMap model){
	
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleado",new Empleado("","Nuevo alumno",""));
		return "add-empleado";
		
	}
	
	@RequestMapping(value="doc-empleado", method = RequestMethod.GET) public String docEmpleado(ModelMap model,@RequestParam String dni){
		
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("docsEmpleado", new DocEmpleado(empleadoService.siguienteDoc(dni)));
		model.addAttribute("empleado",empleadoService.entontrarEmpleadoPorDni(dni));
		return "doc-empleado";
		
	}
	


	
	@RequestMapping(value="add-docEmpleado", method = RequestMethod.POST) public String addDocEmpleado(ModelMap model,@Valid DocEmpleado docEmpleado,BindingResult validacion){
	
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		
		if(validacion.hasErrors()) {
			model.addAttribute("empleado", empleadoService.entontrarEmpleadoPorDni(docEmpleado.getDni()));
			model.addAttribute("docsEmpleado", new DocEmpleado(empleadoService.siguienteDoc(docEmpleado.getDni())));
			return "doc-empleado";
		}
		
		String dni = docEmpleado.getDni();
		System.out.print("DNI"+docEmpleado.getDni()+"Comentario"+docEmpleado.getComentario()+"Id"+docEmpleado.getId()+""+docEmpleado.getTipo());
		Empleado empleado = empleadoService.entontrarEmpleadoPorDni(dni);
		
		try {
		
			if (empleado == null) {
				throw new Exception("Empleado desconocido");
			}
			if (model.getAttribute("nickname") == null) {
				throw new Exception("Usuario no registrado");
			}
			
			empleadoService.addDocEmpleado(empleado,docEmpleado);
			empleadoService.modificaEmpleado(empleado, model.getAttribute("nickname").toString());
			model.addAttribute("empleado", empleado);
			model.addAttribute("docsEmpleado", new DocEmpleado(empleadoService.siguienteDoc(dni)));
			return "doc-empleado";
				
			}catch(Exception e){
				model.addAttribute("empleado", empleadoService.entontrarEmpleadoPorDni(dni));
				model.addAttribute("docsEmpleado", new DocEmpleado(empleadoService.siguienteDoc(dni)));
				model.addAttribute("docsEmpleado", new DocEmpleado(empleadoService.siguienteDoc(docEmpleado.getDni())));
				model.addAttribute("errores",e.getMessage());
				return "doc-empleado";
			}
		
	}
	

	@ModelAttribute("interesadosEnLista")
	public Object[] getinteresadosEnLista() {
		return empleadoService.listaInteresadosEn().toArray();
	}

	@ModelAttribute("paisLista")
	public HashMap <String,String> paisLista() {
		return empleadoService.listaPais();
	}
	
	@ModelAttribute("departamentoLista")
	public Object[] departamentoLista() {
		return departamentoService.listaDepartamentos().toArray();
	}
	
	@ModelAttribute("listaFiltro")
	public Object[] listaFiltro() {
		return empleadoService.listaFiltro().toArray();
	}
	
	@ModelAttribute("listaDni")
	public Object[] listaDni() {
		return empleadoService.ListaDni().toArray();
	}
	
	@ModelAttribute("listaDepartamento")
	public Object[] listaDepartamento() {
		return empleadoService.listaDepartamento().toArray();
	}
	
	@ModelAttribute("listaHorario")
	public Object[] listaHorario() {
		return empleadoService.ListaHorario().toArray();
	}
	@ModelAttribute("opcionestipoDoc")
	public Object[] opcionestipoDoc() {
		return empleadoService.opcionestipoDoc().toArray();
	}
	
	@RequestMapping(value="filtro-empleado-avanzado", method = RequestMethod.POST)  public String filtroEmpleadoAvanzado(ModelMap model,@Valid FiltroEmpleadoAvanzado FiltroEmpleadoAvanzado){
		
		paginaService.setPagina(pagina);
		model.addAttribute("empleados",empleadoService.filtroListaEmpleadosAvanzado(FiltroEmpleadoAvanzado));
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleado",new Empleado());
		model.addAttribute("filtroempleado",new FiltroEmpleado());
		model.addAttribute("filtroempleadoavanzado",new FiltroEmpleadoAvanzado());
		
		return "list-empleado";
	}
	

	
	

	@RequestMapping(value="add-empleado", method = RequestMethod.POST) public String addEmpleado(ModelMap model ,@Valid Empleado empleado, BindingResult validacion) {
		
		if (validacion.hasErrors()) {
			return "add-empleado";
		}
		
		String errores="";
		
		try {
			empleadoService.addEmpleado(empleado);
			
			model.clear();
			
			return "redirect:list-empleado";
		
		} catch (EmpleadoDuplicadoException e){
			errores = e.toString();
			model.addAttribute("errores",errores);
		}
		model.addAttribute("empleados",empleadoService.listaEmpleados());
		return "list-empleado";

	}
	
	@RequestMapping(value="filtro-empleado",method = RequestMethod.POST) public String filtroEmpleado(ModelMap model, @RequestParam String tipo,@RequestParam String filtro ) {
	
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("empleados",empleadoService.filtroListaEmpleados(tipo,filtro));
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("filtroempleado",new FiltroEmpleado());
		model.addAttribute("filtroempleadoavanzado",new FiltroEmpleadoAvanzado());

		return "list-empleado";
	}
	
	@RequestMapping(value="del-empleado",method = RequestMethod.GET) public String delEmpleado(ModelMap model, @RequestParam String dni) {
		
		empleadoService.delEmpleado(new Empleado (dni));
		model.clear();
		return "redirect:list-empleado";
		
	}
	
	@RequestMapping(value="mod-empleado",method = RequestMethod.GET) public String modEmpleado(ModelMap model,@RequestParam String dni) {
		
		paginaService.setPagina(pagina);
		model.addAttribute("pagina",paginaService.getPagina());
		model.addAttribute("departamentos",departamentoService.listaDepartamentos());
		Empleado empleadoModificar = empleadoService.entontrarEmpleadoPorDni(dni);
		model.addAttribute("empleado",empleadoModificar);
		return "mod-empleado";
	}
	
	
	@RequestMapping(value="mod-empleado",method = RequestMethod.POST) public String modEmpleado(ModelMap model,@Valid Empleado empleado, BindingResult validacion) {
		if (validacion.hasErrors()) {
			paginaService.setPagina(pagina);
			model.addAttribute("pagina",paginaService.getPagina());
			model.addAttribute("departamentos",departamentoService.listaDepartamentos());
			return "mod-empleado";
		}	
		try {
			empleadoService.modificaEmpleado(empleado,model.getAttribute("nickname").toString());
			model.clear();
			return "redirect:list-empleado";
		}catch (Exception e) {
			paginaService.setPagina(pagina);
			model.addAttribute("pagina",paginaService.getPagina());
			model.addAttribute("departamentos",departamentoService.listaDepartamentos());
			model.addAttribute("errores",e.getMessage());
			return "mod-empleado";
		}
		
	}
	

	


}