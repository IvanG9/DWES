package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.ArrayList;


import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.DocEmpleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.FiltroEmpleadoAvanzado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorEmpleadoDepartamentoNombre;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorEmpleadoDni;
import org.springframework.stereotype.Service;
import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.EmpleadoDuplicadoException;

@Service
public class EmpleadoServicio {

	private static List<Empleado> empleados = new ArrayList<Empleado>();

	static {

		empleados.add(new Empleado("12345678D", "Pepe", "Ingeniero"));
		empleados.add(new Empleado("12345678F", "Maria", "Desarollador"));

	}

	public List<Empleado> listaEmpleados() {

		return empleados;
	}

	public List<Empleado> listaEmpleados(String orden) {

		if (orden == null || orden == "") {
			orden = "nombre";
		}

		switch (orden) {
		case "nombre":
			Collections.sort(empleados);
			break;
		case "dni":
			Collections.sort(empleados, new ComparadorEmpleadoDni());
			break;
		case "departamento":
			Collections.sort(empleados, new ComparadorEmpleadoDepartamentoNombre());
			break;
		}

		return empleados;

	}

	public List<Empleado> filtroListaEmpleados(String tipo, String filtro) {

		List<Empleado> empleadosFiltro = null;

		switch (tipo) {

		case "Nombre":
			empleadosFiltro = empleados.stream().filter(p -> p.getNombre().contains(filtro))
					.collect(Collectors.toList());
			break;
		case "Dni":
			empleadosFiltro = empleados.stream().filter(p -> p.getDni().contains(filtro)).collect(Collectors.toList());
			break;
		case "Departamento":
			empleadosFiltro = empleados.stream().filter(p -> p.getDepartamento().contains(filtro))
					.collect(Collectors.toList());
			break;

		}

		return empleadosFiltro;

	}

	public List<Empleado> filtroListaEmpleadosAvanzado(FiltroEmpleadoAvanzado filtroAvanzado) {

		List<Empleado> empleadosFiltroAvanzado = empleados;

		if (filtroAvanzado.getDepartamento() != "") {
			empleadosFiltroAvanzado = empleadosFiltroAvanzado.stream()
					.filter(p -> p.getDepartamento().contains(filtroAvanzado.getDepartamento()))
					.collect(Collectors.toList());
		}

		if (filtroAvanzado.getDni() != "") {
			empleadosFiltroAvanzado = empleadosFiltroAvanzado.stream()
					.filter(p -> p.getDni().contains(filtroAvanzado.getDni())).collect(Collectors.toList());
		}

		if (filtroAvanzado.getHorario() != "") {
			empleadosFiltroAvanzado = empleadosFiltroAvanzado.stream()
					.filter(p -> p.getHorario().contains(filtroAvanzado.getHorario())).collect(Collectors.toList());
		}

		return empleadosFiltroAvanzado;
	}
	
	public void addDocEmpleado (Empleado empleado, DocEmpleado docEmpleado) {
		ArrayList<DocEmpleado> nuevaLista = empleado.getDocsEmpleado();
		if (nuevaLista == null) {
			nuevaLista = new ArrayList<DocEmpleado>();
		}
		nuevaLista.add(docEmpleado);
		empleado.setDocsEmpleado(nuevaLista);
	}
	
	public int siguienteDoc(String dni) {
		Empleado empleadoEncontrado = entontrarEmpleadoPorDni(dni);
		if(empleadoEncontrado.getDocsEmpleado() == null){
			return 1;
		} else {
			return empleadoEncontrado.getDocsEmpleado().size()+1;
		}
	}
	
	public void addEmpleado(Empleado empleado) throws EmpleadoDuplicadoException {
		try {
			existeEmpleado(empleado);
			empleados.add(empleado);
		} catch (EmpleadoDuplicadoException e) {
			throw e;
		}
	}

	public void delEmpleado(Empleado empleado) {

		empleados.remove(empleado);

	}

	public boolean existeEmpleado(Empleado empleado) throws EmpleadoDuplicadoException {
		Empleado empleadoExistente = entontrarEmpleadoPorDni(empleado.getDni());
		if (empleadoExistente != null) {
			throw new EmpleadoDuplicadoException(empleadoExistente, empleado);
		} else {
			return false;
		}
	}

	public Empleado entontrarEmpleadoPorDni(String dni) {

		Empleado empleadoDuplicado = null;
		for (int i = 0; i < empleados.size(); i++) {
			if (empleados.get(i).getDni().equalsIgnoreCase(dni)) {
				empleadoDuplicado = empleados.get(i);
				break;
			}
		}
		return empleadoDuplicado;
	}

	public void modificaEmpleado(Empleado empleadoModificado, String usuarioModificacion) throws Exception {

		if (empleadoModificado == null || usuarioModificacion.equals("")) {
			throw new Exception("No se encuentran los datos del empleado o del usuario de modificacion");
		}

		Empleado empleadoActual = null;

		for (int i = 0; i < empleados.size(); i++) {
			if (empleados.get(i).equals(empleadoModificado)) {
				System.out.println(empleadoModificado.getDni());
				empleadoActual = empleados.get(i);
				break;
			}
		}

		if (empleadoActual.sePuedeModificarUtilizando(empleadoModificado)) {
			empleados.remove(empleadoActual);
			empleadoModificado.setUser(usuarioModificacion);
			empleadoModificado.setTs(new Date());
			empleados.add(empleadoModificado);

		} else {
			throw new Exception(empleadoActual.mensajeNoSePuedeModificar());
		}

	}

	public List<String> listaInteresadosEn() {

		List<String> listaInteresadosEn = new ArrayList<String>();

		listaInteresadosEn.add("Backend");
		listaInteresadosEn.add("Frontend");

		return listaInteresadosEn;
	}

	public HashMap<String, String> listaPais() {

		HashMap<String, String> listaPais = new HashMap<String, String>();

		listaPais.put("ES", "España");
		listaPais.put("FR", "Francia");
		listaPais.put("AL", "Alemania");

		return listaPais;
	}

	public List<String> moduloLista() {

		List<String> moduloLista = new ArrayList<String>();

		moduloLista.add("Programacion");
		moduloLista.add("Desarrollo Web en Entorno Servidor");
		moduloLista.add("Sistemas informaticos");

		return moduloLista;
	}

	public List<String> listaFiltro() {

		List<String> listaFiltro = new ArrayList<String>();

		listaFiltro.add("Dni");
		listaFiltro.add("Nombre");
		listaFiltro.add("Departamento");

		return listaFiltro;
	}
	

	public List<String> opcionestipoDoc() {

		List<String> opcionestipoDoc = new ArrayList<String>();

		opcionestipoDoc.add("Certificado");
		opcionestipoDoc.add("Justificante");
		opcionestipoDoc.add("Solicitud");

		return opcionestipoDoc;
	}

	public Stream<String> ListaDni() {

		Stream<String> ListaDni = empleados.stream().map(p -> p.getDni()).distinct().sorted();
		return ListaDni;

	}

	public Stream<String> listaDepartamento() {

		Stream<String> listaDepartamento = empleados.stream().map(p -> p.getDepartamento()).distinct().sorted();
		return listaDepartamento;

	}

	public Stream<String> ListaHorario() {

		Stream<String> ListaHorario = empleados.stream().map(p -> p.getHorario()).distinct().sorted();
		return ListaHorario;

	}

	
	

}