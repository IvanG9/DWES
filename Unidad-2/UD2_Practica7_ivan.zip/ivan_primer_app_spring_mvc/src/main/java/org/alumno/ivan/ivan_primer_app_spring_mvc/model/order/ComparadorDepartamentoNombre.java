package org.alumno.ivan.ivan_primer_app_spring_mvc.model.order;

import java.util.Comparator;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Departamento;

public class ComparadorDepartamentoNombre implements Comparator<Departamento>{
	@Override
	public int compare (Departamento a1, Departamento a2) {
				
			return a1.getNombre().compareTo(a2.getNombre());
		
	}
	
}	
