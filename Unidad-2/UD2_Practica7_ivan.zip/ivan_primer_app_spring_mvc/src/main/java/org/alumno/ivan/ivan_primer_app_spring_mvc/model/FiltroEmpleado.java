package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

public class FiltroEmpleado {

	private String filtro;
	private String tipo;
	
	public FiltroEmpleado(String filtro, String tipo) {
		super();
		this.filtro = filtro;
		this.tipo = tipo;
	}
	
	public FiltroEmpleado() {}
	
	public String getFiltro() {
		return filtro;
	}
	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	
	
}
