package org.alumno.ivan.ivan_primer_app_spring_mvc.mvc;

import javax.validation.Valid;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Pagina;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Usuario;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LogErrorService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.LoginService;
import org.alumno.ivan.ivan_primer_app_spring_mvc.srv.PaginaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("nickname")

	public class LoginController {
	Pagina paginaActual = new Pagina("Home","login");
	@Autowired
	LoginService loginService;
	@Autowired
	LogErrorService logErrorService;
	@Autowired
	PaginaService paginaService;
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String mostrarLogin(ModelMap model) {
		paginaService.setPagina(paginaActual);
		model.put("pagina",paginaService.getPagina());
		model.put("usuario",new Usuario());
		return "login";
	}
	

	@RequestMapping(value="/", method = RequestMethod.GET)
	public String mostrarLoginMain(ModelMap model) {
		paginaService.setPagina(paginaActual);
		model.put("pagina",paginaService.getPagina());
		model.put("usuario",new Usuario());
		return "login";
	}
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String procesaLogin(ModelMap model,@Valid Usuario usuariologin,BindingResult validacion) {
			
		if (validacion.hasErrors()) {
			paginaService.setPagina(paginaActual);
			model.addAttribute("pagina",paginaService.getPagina());
			model.addAttribute("usuario",usuariologin);
			return "login";
		}

		if( !loginService.usuarioValido(usuariologin)){
			model.put("pagina",paginaService.getPagina());
			logErrorService.addLogError("Login", "Login incorrecto de '"+ usuariologin.getNickname()+"'");
			model.put("errores","El usuario o la contraseña son incorectos");
			model.put("usuario",new Usuario());
			return "login";
		}
		model.put("pagina",paginaService.getPagina());
		model.put("usuario",loginService.encontrarUsuarioPorNickname(usuariologin));
		model.put("nickname", usuariologin.getNickname());
		return "bienvenida";
		
		
	}
	
	@RequestMapping(value="logout", method = RequestMethod.GET)
	public String Logout(ModelMap model) {
		paginaService.setPagina(paginaActual);
		model.put("pagina",paginaService.getPagina());
		model.put("usuario",new Usuario());
		return "login";
	}
	
	@RequestMapping(value="bienvenida", method = RequestMethod.GET)
	public String Bienvenida() {
		return "bienvenida";
	}
	
}