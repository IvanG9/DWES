package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

public class FiltroEmpleadoAvanzado {

	String dni;
	String departamento;
	String horario;

	public FiltroEmpleadoAvanzado(String dni, String departamento, String horario) {
		super();
		this.dni = dni;
		this.departamento = departamento;
		this.horario = horario;
	}
	
	
	
	public FiltroEmpleadoAvanzado() {

	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}



	@Override
	public String toString() {
		return "HOLA [dni=" + dni + ", departamento=" + departamento + ", horario=" + horario + "]";
	}

	
	
}
