package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class DocEmpleado {

	@Pattern(regexp="[0-9]{8}[A-Za-z]{1}",message="El Dni debe de tener 8 numeros y una letra")
	private String dni;
	@NotNull(message="El id no puede estar vacio")
	private int id;
	@NotNull(message="El tipo no puede estar vacio")
	private String tipo;
	@Size(min=10, message="Los comentarios deben tener al menos 10 caracteres")
	private String comentario;

	
	public DocEmpleado(String dni, int id, String tipo, String comentario) {
		super();
		this.dni = dni;
		this.id = id;
		this.tipo = tipo;
		this.comentario = comentario;
	}
	
	public DocEmpleado() {
		
	}
	
	public DocEmpleado(int id) {
		super();
		this.id = id;
	}
	
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	
	
	
	
	
	
}
