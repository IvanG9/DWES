package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.ArrayList;

import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Usuario;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

	private static ArrayList <Usuario> usuarios = new ArrayList <Usuario>(); 
	
	static{
		
		usuarios.add(new Usuario("joseramon","miPassword@1","josera"));
		usuarios.add(new Usuario("ivan123","miPassword@1","ivan"));
		
	}
	
	public Usuario encontrarUsuarioPorNickname(Usuario usuarioLogin) {
		
		Usuario usuarioNick = null;
		for(int i=0; i < usuarios.size(); i++) {
			if(usuarios.get(i).getNickname().equals(usuarioLogin.getNickname())) {
				usuarioNick = usuarios.get(i);
				break;
			}
		}
		return usuarioNick;
	}
	
	
	public boolean usuarioValido (Usuario usuarioLogin) {
		
		Usuario UsuarioEncontrado = encontrarUsuarioPorNickname(usuarioLogin);
		if(UsuarioEncontrado!=null) 
		if(UsuarioEncontrado.getPassword().equals(usuarioLogin.getPassword())) {
			return true;
		}
			
		return false;	
		
	}
	
	
	
	
}
