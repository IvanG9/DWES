package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

import java.util.Objects;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Usuario {
	private static final long serialVersionUID = 1L;
	
	@Size(min = 4, message = "El nombre debe de tener un tamaño minimo de 4 caracteres")
	String nickname;
	@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{8,16}$" ,
			message = "el password debe tener entre 8 y 16 caracteres, y al menos un dígito, una minúscula, una mayúscula y un carácter no alfanumérico.")
	String password;
	String nombre;
	
	@Override
	public int hashCode() {
		return Objects.hash(nickname);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		return Objects.equals(nickname, other.nickname);
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Usuario(String nickname,String password,String nombre) {
		super();
		this.nickname = nickname;
		this.password = password;
		this.nombre = nombre;
	}

	public Usuario() {
		
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


}
