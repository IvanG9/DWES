package org.alumno.ivan.ivan_primer_app_spring_mvc.model;

import java.util.Objects;

import javax.validation.constraints.Size;

import java.io.Serializable;

public class Departamento implements Comparable<Departamento> {

 	private int id;
    private String nombre;
  	@Size(min=5,message="El nombre debe de tener un tamaño minimo de 5")

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Departamento other = (Departamento) obj;
		return id == other.id;
	}
	public Departamento(int id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}
    
	public int compareTo(Departamento Departamento) { 
	    
	    return id-Departamento.getId();
	}
	
	@Override
	public String toString() {
		return nombre;
	}
	
	//Nuevos metodos
	
	public Departamento() {
		
	}
	
	public Departamento(int id) {
		super();
		this.id = id;
	}
	
	
	
}