package org.alumno.ivan.ivan_primer_app_spring_mvc.srv;

import java.util.ArrayList;


import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.Empleado;	
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorEmpleadoDepartamentoNombre;
import org.alumno.ivan.ivan_primer_app_spring_mvc.model.order.ComparadorEmpleadoDni;
import org.springframework.stereotype.Service;
import org.alumno.ivan.ivan_primer_app_spring_mvc.excepciones.EmpleadoDuplicadoException;


@Service
public class EmpleadoServicio {
	
	private static ArrayList <Empleado> empleados = new ArrayList <Empleado>(); 
	
		static{
			
			empleados.add(new Empleado("12345678D","Pepe","Ingeniero"));
			empleados.add(new Empleado("12345678F","Maria","Desarollador"));
			
		}
		
		public ArrayList<Empleado> listaEmpleados(){
			
			return empleados;
		}
		
		
		
		public ArrayList<Empleado>listaEmpleados(String orden){
			
			if(orden == null || orden == "") {
				orden = "nombre";
			}
			
			switch (orden) {
				case "nombre":
					Collections.sort(empleados);
		            break;
				case "dni":
					Collections.sort(empleados,new ComparadorEmpleadoDni());
					break;
				case "departamento":
					Collections.sort(empleados,new ComparadorEmpleadoDepartamentoNombre());
					break;
			}
			
		         return empleados;
			
		}
		
		
		public void addEmpleado(Empleado empleado) throws EmpleadoDuplicadoException{
			try {
				existeEmpleado(empleado);
				empleados.add(empleado);
			}catch(EmpleadoDuplicadoException e) {
				throw e;
			}
		}
		
		public void delEmpleado(Empleado empleado) {
			
			empleados.remove(empleado);
			
		}
		
		public boolean existeEmpleado(Empleado empleado) throws EmpleadoDuplicadoException{
			Empleado empleadoExistente = entontrarEmpleadoPorDni(empleado.getDni());
			if(empleadoExistente!=null) {
				throw new EmpleadoDuplicadoException(empleadoExistente, empleado);
			} else {
				return false;
			}
		}
		
		public Empleado entontrarEmpleadoPorDni(String dni) {
			
			Empleado empleadoDuplicado = null;
			for(int i=0; i < empleados.size(); i++) {
				if(empleados.get(i).getDni().equalsIgnoreCase(dni)) {
					empleadoDuplicado = empleados.get(i);
					break;
				}
			}
			return empleadoDuplicado;
		}
		
	  public void modificaEmpleado(Empleado empleadoModificado,String usuarioModificacion) throws Exception{
		  
		  if(empleadoModificado == null || usuarioModificacion.equals("")) {
			  throw new Exception("No se encuentran los datos del empleado o del usuario de modificacion");
		  }
		  
		  Empleado empleadoActual = null;
		  
		  for(int i = 0; i < empleados.size(); i++) {
			  if(empleados.get(i).equals(empleadoModificado)) {
				  System.out.println(empleadoModificado.getDni());
				  empleadoActual = empleados.get(i);
				  break;
			  }
		  }
		  	
		  if (empleadoActual.sePuedeModificarUtilizando(empleadoModificado)) {
			  empleados.remove(empleadoActual);
			  empleadoModificado.setUser(usuarioModificacion);
			  empleadoModificado.setTs(new Date());
			  empleados.add(empleadoModificado);
			  
		  }else {
			  throw new Exception(empleadoActual.mensajeNoSePuedeModificar());
		  }
		  
	  }



	public List<String> listaInteresadosEn() {
		
		List <String>  listaInteresadosEn = new ArrayList<String> ();
				
		listaInteresadosEn.add("Backend");
		listaInteresadosEn.add("Frontend");
		
		return listaInteresadosEn;
	}

	public HashMap<String,String> listaPais() {
		
		HashMap <String,String>  listaPais = new HashMap<String,String>();
				
		listaPais.put("ES","España");
		listaPais.put("FR","Francia");
		listaPais.put("AL","Alemania");
		
		return listaPais;
	}
		
	public List<String> moduloLista() {
		
		List <String>  moduloLista = new ArrayList<String> ();
				
		moduloLista.add("Programacion");
		moduloLista.add("Desarrollo Web en Entorno Servidor");
		moduloLista.add("Sistemas informaticos");
		
		return moduloLista;
	}
	
}