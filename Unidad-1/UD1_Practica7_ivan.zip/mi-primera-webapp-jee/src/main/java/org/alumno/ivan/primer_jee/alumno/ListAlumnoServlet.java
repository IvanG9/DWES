package org.alumno.ivan.primer_jee.alumno;

import java.io.IOException;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;
import org.alumno.ivan.primer_jee.login.LoginService;
import org.alumne.ivan.primer_jee.pagina.Pagina;

@WebServlet(urlPatterns = "/list-alumno.do")

public class ListAlumnoServlet extends HttpServlet {

	AlumnoService alumnoServicio = new AlumnoService();
	
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getSession().setAttribute("pagina", new Pagina("Alumnos", "List-alumno.do"));
	request.setAttribute("alumnos", alumnoServicio.listaAlumnos());
	request.getRequestDispatcher("WEB-INF/views/list-alumno.jsp").forward(request, response);
	
	}
	}