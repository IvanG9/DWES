package org.alumno.ivan.primer_jee.alumno;

import java.util.ArrayList;
import java.util.List;

import org.alumno.ivan.primer_jee.login.*;

public class AlumnoService {
	
	private static List <Alumno> alumnos = new ArrayList <Alumno>(); 
	
		static{
			alumnos.add(new Alumno("12345678D","Jose",23,"DAM",1));
			alumnos.add(new Alumno("12345678B","Pepe",22,"DAW",2));
			alumnos.add(new Alumno("12345678C","Ivan",21,"DAM",1));
			alumnos.add(new Alumno("12345678E","Laura",32,"DAW",2));
			
		}
		
		public List<Alumno> listaAlumnos(){
			
			return alumnos;
		}
		
		public void addAlumnos(Alumno alumno) {
			
			alumnos.add(alumno);
		
		}
		
		public void delAlumnos(Alumno alumno) {
			
			alumnos.remove(alumno);
			
		}
}