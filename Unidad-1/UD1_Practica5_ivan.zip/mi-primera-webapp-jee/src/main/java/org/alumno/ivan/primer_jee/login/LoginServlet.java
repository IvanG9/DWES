package org.alumno.ivan.primer_jee.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;


@WebServlet(urlPatterns = "/login.do")

public class LoginServlet extends HttpServlet {
	
	LoginService servicio = new LoginService();
	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		request.getRequestDispatcher("WEB-INF/views/login.jsp").forward(request, response);
		
	}

    @Override
        protected void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
			
    	String nombre = request.getParameter("nombre");
    	String password = request.getParameter("password");
    		if (servicio.usuarioValido(nombre,password)) {
    			request.getSession().setAttribute("nombre", nombre);
    			response.sendRedirect("alumno.do");
    			
    		}else {
    			request.setAttribute("nombre", nombre);
    			request.setAttribute("errores", "Usuario " +nombre+ " o contraseña incorrecto");
    			request.getRequestDispatcher("WEB-INF/views/login.jsp").forward(request, response);
    		}
 
    		
    		
		}


}