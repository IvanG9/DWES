package org.alumno.ivan.primer_jee.alumno;

import java.util.ArrayList;
import java.util.List;

import org.alumno.ivan.primer_jee.login.*;

public class AlumnoService {
	
	private static List <Alumno> alumnos = new ArrayList <Alumno>(); 
	
		static{
			alumnos.add(new Alumno("Jose"));
			alumnos.add(new Alumno("Pedro"));
			alumnos.add(new Alumno("Juan"));
			alumnos.add(new Alumno("Maria"));
			
		}
		
		public List<Alumno> listaAlumnos(){
			
			return alumnos;
		}
		
		public void addAlumnos(Alumno alumno) {
			
			alumnos.add(alumno);
		
		}
		
		public void delAlumnos(Alumno alumno) {
			
			alumnos.remove(alumno);
			
		}
}