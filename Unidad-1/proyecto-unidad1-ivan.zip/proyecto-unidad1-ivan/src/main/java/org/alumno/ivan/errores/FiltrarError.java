package org.alumno.ivan.errores;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.alumno.ivan.pagina.Pagina;
import org.alumno.ivan.empleados.Empleado;
import org.alumno.ivan.empleados.EmpleadoDuplicadoException;
import org.alumno.ivan.errores.ErrorServicio;

@WebServlet(urlPatterns = "/filtrar-error.do")

public class FiltrarError extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	ErrorServicio errorServicio = new ErrorServicio();
	
	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	
	String filtro = request.getParameter("filtro");
	String tipo = request.getParameter("tipo");
	
	try {
		if(filtro == null && tipo == null)
		throw new Exception("");

			request.setAttribute("errores",errorServicio.filtroErrores(tipo,filtro));

	} catch(Exception e) {
		request.setAttribute("errores1", "No puedes filtrar si no pones algo");

	}
	request.getRequestDispatcher("WEB-INF/views/list-errores.jsp").forward(request, response);
		
	}
		
	
	
	
}
