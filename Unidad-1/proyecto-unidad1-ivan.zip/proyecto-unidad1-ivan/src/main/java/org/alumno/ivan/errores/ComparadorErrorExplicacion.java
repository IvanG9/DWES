package org.alumno.ivan.errores;

import java.util.Comparator;


import org.alumno.ivan.errores.Error;


public class ComparadorErrorExplicacion implements Comparator<Error>{
	@Override
	public int compare (Error a1, Error a2) {

			return a1.getExplicacion().compareTo(a2.getExplicacion());
		
	}
}	