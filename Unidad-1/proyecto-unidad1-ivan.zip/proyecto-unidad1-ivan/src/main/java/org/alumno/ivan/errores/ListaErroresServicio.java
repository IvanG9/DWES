package org.alumno.ivan.errores;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.pagina.Pagina;
import org.alumno.ivan.errores.ErrorServicio;

@WebServlet(urlPatterns = "/list-errores.do")

public class ListaErroresServicio extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	ErrorServicio errorServicio = new ErrorServicio();

	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getSession().setAttribute("pagina", new Pagina("error", "list-errores.do"));
	request.setAttribute("errores", errorServicio.listaErrores(request.getParameter("orden")));
	request.getRequestDispatcher("WEB-INF/views/list-errores.jsp").forward(request, response);
	
	}
	}