package org.alumno.ivan.filtros;
import java.io.IOException;


import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.errores.Error;
import org.alumno.ivan.errores.ErrorServicio;


@WebFilter(urlPatterns="*.do")

public class ComprobarLoginFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException{}
	
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request= (HttpServletRequest) servletRequest;
		System.out.println(request.getRequestURI());
		if (request.getSession().getAttribute("nombre") !=null) {
			chain.doFilter(request, servletResponse);
		}else {
			if(request.getRequestURI().contains("login.do")) {
				chain.doFilter(request, servletResponse);

			}else {
				HttpServletResponse response = (HttpServletResponse) servletResponse;
				response.sendRedirect("login.do");
				
				ErrorServicio errorServicio = new ErrorServicio();
				String tipo = "Acceso denegado";
				String explicacion = "Usuario anónimo ha intentando acceder a la web";
				errorServicio.addError(new Error(tipo,explicacion));
				
			}
		}
		
	}
	
	@Override
	public void destroy() {}
}