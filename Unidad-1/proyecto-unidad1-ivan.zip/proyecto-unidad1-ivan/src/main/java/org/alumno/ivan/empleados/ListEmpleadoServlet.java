package org.alumno.ivan.empleados;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.empleados.EmpleadoServicio;
import org.alumno.ivan.login.LoginServicio;
import org.alumno.ivan.pagina.Pagina;
import org.alumno.ivan.departamentos.*;

@WebServlet(urlPatterns = "/list-empleado.do")

public class ListEmpleadoServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	EmpleadoServicio empleadoServicio = new EmpleadoServicio();
	DepartamentoServicio departamentoServicio = new DepartamentoServicio();
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getSession().setAttribute("pagina", new Pagina("empleado", "list-empleado.do"));
	request.setAttribute("empleados", empleadoServicio.listaEmpleados(request.getParameter("orden")));
	request.setAttribute("departamentos", departamentoServicio.listaDepartamentos());
	request.getRequestDispatcher("WEB-INF/views/list-empleado.jsp").forward(request, response);
	
	}
	}