package org.alumno.ivan.empleados;

import org.alumno.ivan.empleados.Empleado;
import org.alumno.ivan.errores.Error;
import org.alumno.ivan.errores.ErrorServicio;

public class EmpleadoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Empleado empleadoExistente;
	private Empleado empleadoNuevo;
	
	public EmpleadoDuplicadoException(Empleado empleadoExistente, Empleado empleadoNuevo) {
		super();
		this.empleadoExistente = empleadoExistente;
		this.empleadoNuevo = empleadoNuevo;
	}

	@Override
	public String toString() {
		
		
		ErrorServicio errorServicio = new ErrorServicio();
		String tipo = "Inserción duplicada";
		String explicacion = "Inserción duplicada del empleado "+ empleadoExistente.getDni();
		errorServicio.addError(new Error(tipo,explicacion));
		
		
		return "ERROR insertando Empleado: <br>"
				+ "Empleado existente:<br>"
				+ "Dni: "+empleadoExistente.getDni()+"<br>"
				+ "Nombre: "+empleadoExistente.getNombre()+"<br>"
				+ "Empleado nuevo: <br>"
				+ "Dni: "+empleadoNuevo.getDni()+"<br>"
				+ "Nombre: "+empleadoNuevo.getNombre();
	}
		
	
	
}