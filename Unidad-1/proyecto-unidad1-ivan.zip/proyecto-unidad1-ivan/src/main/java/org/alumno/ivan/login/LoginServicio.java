package org.alumno.ivan.login;

import org.alumno.ivan.errores.Error;
import org.alumno.ivan.errores.ErrorServicio;

public class LoginServicio {
	
	public boolean usuarioValido(String usuario, String password)  {
		
		if (usuario.contentEquals("ivan") && password.contentEquals("ivan")){
			
			return true;
			
		}else {
			ErrorServicio errorServicio = new ErrorServicio();
			String tipo = "Login incorrecto";
			String explicacion = "Login incorrecto de " + usuario;
			errorServicio.addError(new Error(tipo,explicacion));
		}
		
		return false;
		
	}
}