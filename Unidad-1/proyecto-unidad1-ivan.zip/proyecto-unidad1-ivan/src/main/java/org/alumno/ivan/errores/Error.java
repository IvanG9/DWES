package org.alumno.ivan.errores;

import java.util.Objects;

public class Error implements Comparable<Error> {
	  
	private static int count = 0; 
	public int id;
	public String tipo;
	public String explicacion;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getExplicacion() {
		return explicacion;
	}

	public void setExplicacion(String explicacion) {
		this.explicacion = explicacion;
	}

	public Error(String tipo, String explicacion) {
		super();
		this.id = ++count;
		this.tipo = tipo;
		this.explicacion = explicacion;
	}

	@Override
	public int compareTo(Error error) {
		
		return id-error.getId();
		
	}


}
