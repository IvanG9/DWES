package org.alumno.ivan.empleados;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.empleados.*;
import org.alumno.ivan.login.LoginServicio;


@WebServlet(urlPatterns = "/del-empleado.do")

public class DelEmpleadoServlet extends HttpServlet {

	EmpleadoServicio EmpleadoServicio = new EmpleadoServicio();

	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		for(int i = 0; i < EmpleadoServicio.listaEmpleados().size() ; i++){
			if(EmpleadoServicio.listaEmpleados().get(i).getDni().equalsIgnoreCase(request.getParameter("dni"))) {
				
				request.setAttribute("dni",EmpleadoServicio.listaEmpleados().get(i).getDni());
				request.setAttribute("nombre",EmpleadoServicio.listaEmpleados().get(i).getNombre());
				request.setAttribute("departamento",EmpleadoServicio.listaEmpleados().get(i).getDepartamento());

			}
		}
		
		request.getRequestDispatcher("WEB-INF/views/del-empleado.jsp").forward(request, response);

	}
	
	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
				
		for(int i = 0; i < EmpleadoServicio.listaEmpleados().size() ; i++){
			if(EmpleadoServicio.listaEmpleados().get(i).getDni().equalsIgnoreCase(request.getParameter("empleado"))) {
				EmpleadoServicio.delEmpleado(EmpleadoServicio.listaEmpleados().get(i));
			}
		}
		
		response.sendRedirect("list-empleado.do");
		
	}
	}