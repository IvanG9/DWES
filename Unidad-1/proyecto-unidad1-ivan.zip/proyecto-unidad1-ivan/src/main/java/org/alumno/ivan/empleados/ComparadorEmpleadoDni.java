package org.alumno.ivan.empleados;


import java.util.Comparator;

import org.alumno.ivan.empleados.*;

public class ComparadorEmpleadoDni implements Comparator<Empleado>{
	@Override
	public int compare (Empleado a1, Empleado a2) {
				
			return a1.getDni().compareTo(a2.getDni());
		
	}
	
}	