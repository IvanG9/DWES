package org.alumno.ivan.errores;

import java.util.ArrayList;
import java.util.Collections;

import org.alumno.ivan.errores.Error;

public class ErrorServicio {
	
	private static ArrayList <Error> errores = new ArrayList <Error>(); 

	public ArrayList<Error> listaErrores(){
		
		return errores;
	}
	
	public ArrayList<Error>listaErrores(String orden){
		
		if(orden == null || orden == "") {
			orden = "nombre";
		}
		
		switch (orden) {
			case "id":
				Collections.sort(errores);
	            break;
			case "tipo":
				Collections.sort(errores,new ComparadorErrorTipo());
				break;
			case "explicacion":
				Collections.sort(errores,new ComparadorErrorExplicacion());
				break;
		
		}
		
	         return errores;
		
	}
	
	public void addError(Error error){
		errores.add(error);
	}
	
	public void delError(Error error) {
		errores.remove(error);
	}
	
	public ArrayList<Error> filtroErrores(String tipo,String filtro){
		
		ArrayList <Error> erroresConFiltro = new ArrayList <Error>(); 
		
		switch(tipo) {
		case "id":
			for(int i = 0; i < errores.size() ; i++){
				if(errores.get(i).getId() == Integer.parseInt(filtro))
				erroresConFiltro.add(errores.get(i));		
				}
			break;
		case "tipo":
			for(int i = 0; i < errores.size() ; i++){
				if(errores.get(i).getTipo().contains(filtro))
					erroresConFiltro.add(errores.get(i));	
				}
			break;
		case "explicacion":
			for(int i = 0; i < errores.size() ; i++){
				if(errores.get(i).getExplicacion().contains(filtro)) 
				erroresConFiltro.add(errores.get(i));
				}
			break;
		}
		
		return erroresConFiltro;
	} 
	
}
