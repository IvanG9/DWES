package org.alumno.ivan.departamentos;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.departamentos.DepartamentoServicio;
import org.alumno.ivan.login.LoginServicio;


@WebServlet(urlPatterns = "/del-departamento.do")

public class DelDepartamentoServlet extends HttpServlet {

	DepartamentoServicio departamentoServicio = new DepartamentoServicio();

	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		for(int i = 0; i < departamentoServicio.listaDepartamentos().size() ; i++){
			if(departamentoServicio.listaDepartamentos().get(i).getId() == Integer.parseInt(request.getParameter("id"))) {
				
				request.setAttribute("id",departamentoServicio.listaDepartamentos().get(i).getId());
				request.setAttribute("nombre",departamentoServicio.listaDepartamentos().get(i).getNombre());

			}
		}
		
		request.getRequestDispatcher("WEB-INF/views/del-departamento.jsp").forward(request, response);

	}
	

	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
				
		
		for(int i = 0; i < departamentoServicio.listaDepartamentos().size() ; i++){
			if(departamentoServicio.listaDepartamentos().get(i).getId() == Integer.parseInt(request.getParameter("departamento"))) {
				departamentoServicio.delDepartamento(departamentoServicio.listaDepartamentos().get(i));
			}
		}
		
		response.sendRedirect("list-departamento.do");
		
		
	}
	}