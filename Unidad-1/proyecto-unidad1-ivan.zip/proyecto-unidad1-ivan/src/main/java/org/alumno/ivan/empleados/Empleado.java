package org.alumno.ivan.empleados;

import java.util.Objects;


public class Empleado implements Comparable<Empleado> {
	
	  	private String dni;
	    private String nombre;
	    private String departamento;
	    
	    
		public  String getDni() {
			return dni;
		}
		public void setDni(String dni) {
			this.dni = dni;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getDepartamento() {
			return departamento;
		}
		public void setDepartamento(String departamento) {
			this.departamento = departamento;
		}
		
		
		
		public Empleado(String dni, String nombre,String departamento ) {
			super();
			this.dni = dni;
			this.nombre = nombre;
			this.departamento = departamento;
;
		}
		
		@Override
		public int hashCode() {
			return Objects.hash(dni);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Empleado other = (Empleado) obj;
			return Objects.equals(dni, other.dni);
		}
	
		@Override
	    public int compareTo(Empleado Empleado) { 
	        return nombre.compareTo(Empleado.getNombre());
	    }
	    
	
}
