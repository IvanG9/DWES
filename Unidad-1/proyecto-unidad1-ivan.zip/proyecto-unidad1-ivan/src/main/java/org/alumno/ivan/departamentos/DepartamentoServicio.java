package org.alumno.ivan.departamentos;

import java.util.ArrayList;

import java.util.Collection;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;

import org.alumno.ivan.login.*;
import org.alumno.ivan.departamentos.Departamento;
import org.alumno.ivan.empleados.Empleado;
import org.alumno.ivan.departamentos.ComparadorDepartamentoNombre;

public class DepartamentoServicio {
	
	private static ArrayList <Departamento> departamentos = new ArrayList <Departamento>(); 
	
		static{
			
			departamentos.add(new Departamento(1,"Ingeniero"));
			departamentos.add(new Departamento(2,"Programador"));
			
		}
		
		
		public ArrayList<Departamento> listaDepartamentos(){
			
			return departamentos;
		}
		
		
		public ArrayList<Departamento>listaDepartamentos(String orden){
			
			if(orden == null || orden == "") {
				orden = "id";
			}
			
			switch (orden) {
				case "nombre":
					Collections.sort(departamentos,new ComparadorDepartamentoNombre());
					break;
				case "id":
					Collections.sort(departamentos);
			}
			
		         return departamentos;
			
		}
		
		
		public void addDepartamento(Departamento departamento) throws DepartamentoDuplicadoException{
			try {
				existeDepartamento(departamento);
				departamentos.add(departamento);
			}catch(DepartamentoDuplicadoException e) {
				throw e;
			}
		}
		
		public void delDepartamento(Departamento departamento) {
			
			departamentos.remove(departamento);
			
		}
		
		public boolean existeDepartamento(Departamento departamento) throws DepartamentoDuplicadoException{
			Departamento empleadoExistente = entontrarDepartamentoPorId(departamento.getId());
			if(empleadoExistente!=null) {
				throw new DepartamentoDuplicadoException(empleadoExistente, departamento);
			} else {
				return false;
			}
		}
		
		public Departamento entontrarDepartamentoPorId(int id) {
			
			Departamento departamentoDuplicado = null;
			for(int i=0; i < departamentos.size(); i++) {
				if(departamentos.get(i).getId() == (id)) {
					departamentoDuplicado = departamentos.get(i);
					break;
				}
			}
			return departamentoDuplicado;
		}
		
		
}