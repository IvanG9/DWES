package org.alumno.ivan.empleados;

import java.io.IOException;

import java.util.InputMismatchException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.alumno.ivan.empleados.EmpleadoServicio;
import org.alumno.ivan.login.LoginServicio;
import org.alumno.ivan.departamentos.*;

@WebServlet(urlPatterns = "/add-empleado.do")

public class AddEmpleadoServlet extends HttpServlet {

	EmpleadoServicio empleadoServicio = new EmpleadoServicio();
	DepartamentoServicio departamentoServicio = new DepartamentoServicio();
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getRequestDispatcher("WEB-INF/views/list-empleado.jsp").forward(request, response);
	
	}

	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		String dni = request.getParameter("dni");
		String nombre = request.getParameter("nombre");
		String departamento = request.getParameter("departamento");
		String errores = "";
		Pattern patron = Pattern.compile("[0-9]{7,8}[A-Z a-z]");
		Matcher mat = patron.matcher(dni);
	     
		try {
			if(!mat.matches()) {
				errores += "Dni incorrecto <br>";
			}
			if(nombre.length() < 3) {
				errores += "El nombre tiene que tener mas de 3 caracteres";
			}
			if(errores != "") {
				throw new Exception(errores);
			}
			empleadoServicio.addEmpleado(new Empleado(dni,nombre,departamento));		
			response.sendRedirect("list-empleado.do");
			
		} catch(EmpleadoDuplicadoException e) {
			request.setAttribute("errores", e.toString());
			request.setAttribute("empleados", empleadoServicio.listaEmpleados(request.getParameter("orden")));
			request.setAttribute("departamentos", departamentoServicio.listaDepartamentos());
			request.getRequestDispatcher("/WEB-INF/views/list-empleado.jsp").forward(request, response);
		} catch(Exception e) {
			request.setAttribute("errores", e.toString());
			request.setAttribute("empleados", empleadoServicio.listaEmpleados(request.getParameter("orden")));
			request.setAttribute("departamentos", departamentoServicio.listaDepartamentos());
			request.getRequestDispatcher("/WEB-INF/views/list-empleado.jsp").forward(request, response);		}

	}
	
}