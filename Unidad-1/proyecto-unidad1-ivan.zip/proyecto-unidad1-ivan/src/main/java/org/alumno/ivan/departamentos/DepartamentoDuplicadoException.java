package org.alumno.ivan.departamentos;

import org.alumno.ivan.departamentos.*;
import org.alumno.ivan.errores.Error;
import org.alumno.ivan.errores.ErrorServicio;

public class DepartamentoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Departamento departamentoExistente;
	private Departamento departamentoNuevo;
	
	public DepartamentoDuplicadoException(Departamento departamentoExistente, Departamento departamentoNuevo) {
		super();
		this.departamentoExistente = departamentoExistente;
		this.departamentoNuevo = departamentoNuevo;
	}

	@Override
	public String toString() {
		
		ErrorServicio errorServicio = new ErrorServicio();
		String tipo = "Inserción duplicada";
		String explicacion = "Inserción duplicada del departamento "+ departamentoExistente.getId();
		errorServicio.addError(new Error(tipo,explicacion));
		
		return "ERROR insertando Alumno: <br>"
				+ "Departamento existente:<br>"
				+ "Id: "+departamentoExistente.getId()+"<br>"
				+ "Nombre: "+departamentoExistente.getNombre()+"<br>"
				+ "Departamento nuevo: <br>"
				+ "Id: "+departamentoNuevo.getId()+"<br>"
				+ "Nombre: "+departamentoNuevo.getNombre();
	}
	
	
	
}