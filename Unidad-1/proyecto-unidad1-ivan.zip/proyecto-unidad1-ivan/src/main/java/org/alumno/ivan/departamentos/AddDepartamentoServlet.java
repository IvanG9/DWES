package org.alumno.ivan.departamentos;

import java.io.IOException;

import java.util.InputMismatchException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.alumno.ivan.login.LoginServicio;
import org.alumno.ivan.departamentos.DepartamentoServicio;


@WebServlet(urlPatterns = "/add-departamento.do")

public class AddDepartamentoServlet extends HttpServlet {

	DepartamentoServicio departamentoServicio = new DepartamentoServicio();
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getRequestDispatcher("WEB-INF/views/list-departamento.jsp").forward(request, response);
	
	}

	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		int id = Integer.parseInt(request.getParameter("id"));
		String nombre = request.getParameter("nombre");
		
		try {
			if(nombre.length() < 3) {
				throw new Exception ("El nombre tiene que tener mas de 3 carracteres");
			}
			departamentoServicio.addDepartamento(new Departamento(id,nombre));
			response.sendRedirect("list-departamento.do");
			
		} catch(DepartamentoDuplicadoException e) {
			request.setAttribute("errores", e.toString());
			request.setAttribute("departamentos", departamentoServicio.listaDepartamentos(request.getParameter("orden")));
			request.getRequestDispatcher("/WEB-INF/views/list-departamento.jsp").forward(request, response);
		} catch(Exception e) {
			request.setAttribute("errores", e.toString());
			request.setAttribute("departamentos", departamentoServicio.listaDepartamentos(request.getParameter("orden")));
			request.getRequestDispatcher("/WEB-INF/views/list-departamento.jsp").forward(request, response);
		}

	}
	
}