package org.alumno.ivan.primer_jee.login;

public class LoginService {
	
	public boolean usuarioValido(String usuario, String password) {
		
		if (usuario.contentEquals("ivan") && password.contentEquals("ivan"))
			return true;
		
		return false;
	}
}