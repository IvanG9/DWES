package org.alumno.ivan.primer_jee.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;


@WebServlet(urlPatterns = "/logout.do")

public class LogoutServlet extends HttpServlet {
	
	LoginService servicio = new LoginService();
	AlumnoService alumnoServicio = new AlumnoService();
	
	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		request.getSession().invalidate();
		response.sendRedirect("login.do");
	}

}