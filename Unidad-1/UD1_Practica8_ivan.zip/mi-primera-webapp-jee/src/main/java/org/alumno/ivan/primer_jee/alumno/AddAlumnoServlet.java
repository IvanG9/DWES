package org.alumno.ivan.primer_jee.alumno;

import java.io.IOException;
import java.util.InputMismatchException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/add-alumno.do")

public class AddAlumnoServlet extends HttpServlet {

	
AlumnoService alumnoServicio = new AlumnoService();
	
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getRequestDispatcher("WEB-INF/views/add-alumno.jsp").forward(request, response);
	
	}


	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		String nombre = request.getParameter("nombre");
		String dni = request.getParameter("dni");
		int edad = Integer.parseInt(request.getParameter("edad"));
		String modulo = request.getParameter("modulo");
		int curso = Integer.parseInt(request.getParameter("curso"));
		
		try {
				for(int i = 0; i < alumnoServicio.listaAlumnos().size() ; i++) {
					if(alumnoServicio.listaAlumnos().get(i).getDni().equals(dni)) {
						request.setAttribute("errores","ERROR insertando Alumno: <br>"+"Alumno Existente:<br>"+"DNI: "+alumnoServicio.listaAlumnos().get(i).getDni()+"<br>Nombre: "+alumnoServicio.listaAlumnos().get(i).getNombre()+
							"<br>Alumno Nuevo: <br>"+ "DNI: " +dni+"<br>Nombre: "+ nombre);
						throw new InputMismatchException("adw");
					}
				}
				alumnoServicio.addAlumnos(new Alumno(dni,nombre,edad,modulo,curso));
				request.setAttribute("alumnos", alumnoServicio.listaAlumnos());
				response.sendRedirect("list-alumno.do");
		}catch(Exception e) {
			request.getRequestDispatcher("WEB-INF/views/add-alumno.jsp").forward(request, response);
		}
		
		
		
		
	
	


	}
	
}