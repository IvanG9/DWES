package org.alumno.ivan.primer_jee.alumno;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;

import org.alumno.ivan.primer_jee.login.*;

public class AlumnoService {
	
	private static ArrayList <Alumno> alumnos = new ArrayList <Alumno>(); 
	
		static{
			alumnos.add(new Alumno("12345678D","Jose",23,"DAM",1));
			alumnos.add(new Alumno("12345678B","Pepe",22,"DAW",2));
			alumnos.add(new Alumno("12345678C","Ivan",21,"DAM",1));
			alumnos.add(new Alumno("12345678E","Laura",32,"DAW",2));
			
		}
		
		public ArrayList<Alumno> listaAlumnos(){
			
			return alumnos;
		}
		
		
		public ArrayList<Alumno>listaAlumnos(String orden){
			
			if(orden == null || orden == "") {
				orden = "nombre";
			}
			
			switch (orden) {
				case "nombre":
					Collections.sort(alumnos);
		            break;
				case "dni":
					Collections.sort(alumnos,new ComparadorAlumnoDni());
					break;
				case "edadNombre":
					Collections.sort(alumnos,new ComparadorAlumnoEdadNombre());
					break;
				case "cicloNombre":
					Collections.sort(alumnos,new ComparadorAlumnoCicloNombre());
					break;
				case "cursoNombre":
					Collections.sort(alumnos,new ComparadorAlumnoCursoNombre());
					break;
			}
			
		         return alumnos;
			
		}
		
		
		public void addAlumno(Alumno alumno) throws AlumnoDuplicadoException{
			try {
				existeAlumno(alumno);
				alumnos.add(alumno);
			}catch(AlumnoDuplicadoException e) {
				throw e;
			}
		}
		
		public void delAlumnos(Alumno alumno) {
			
			alumnos.remove(alumno);
			
		}
		
		public boolean existeAlumno(Alumno alumno) throws AlumnoDuplicadoException{
			Alumno alumnoExistente = encontrarAlumnoPorDni(alumno.getDni());
			if(alumnoExistente!=null) {
				throw new AlumnoDuplicadoException(alumnoExistente, alumno);
			} else {
				return false;
			}
		}
		
		public Alumno encontrarAlumnoPorDni(String dni) {
			
			Alumno alumnoDuplicado = null;
			for(int i=0; i < alumnos.size(); i++) {
				if(alumnos.get(i).getDni().equals(dni)) {
					alumnoDuplicado = alumnos.get(i);
					break;
				}
			}
			return alumnoDuplicado;
		}
		
		
}