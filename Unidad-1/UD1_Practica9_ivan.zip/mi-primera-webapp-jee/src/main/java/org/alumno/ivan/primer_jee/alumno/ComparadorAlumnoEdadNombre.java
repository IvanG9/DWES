package org.alumno.ivan.primer_jee.alumno;

import java.util.Comparator;

public class ComparadorAlumnoEdadNombre implements Comparator<Alumno>{
	@Override
	public int compare (Alumno a1, Alumno a2) {
		
		int compararCurso = a1.getEdad()-(a2.getEdad());
		
		if(compararCurso != 0) {
			return compararCurso;
		}else {
			return a1.getNombre().compareTo(a2.getNombre());
		}
		
	}
	
	
	
}	
	