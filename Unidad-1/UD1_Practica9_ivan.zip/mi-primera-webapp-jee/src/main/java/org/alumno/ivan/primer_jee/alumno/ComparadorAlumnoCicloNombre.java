package org.alumno.ivan.primer_jee.alumno;

import java.util.Comparator;

public class ComparadorAlumnoCicloNombre implements Comparator<Alumno>{
	@Override
	public int compare (Alumno a1, Alumno a2) {
		
		int compararCurso = a1.getModul().compareTo(a2.getModul());
		
		if(compararCurso != 0) {
			return compararCurso;
		}else {
			return a1.getNombre().compareTo(a2.getNombre());
		}
		
	}
	
	
	
}	
	
	
	
	
