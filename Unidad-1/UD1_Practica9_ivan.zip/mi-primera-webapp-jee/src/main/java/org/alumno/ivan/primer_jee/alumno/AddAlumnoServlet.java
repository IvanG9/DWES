package org.alumno.ivan.primer_jee.alumno;

import java.io.IOException;
import java.util.InputMismatchException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/add-alumno.do")

public class AddAlumnoServlet extends HttpServlet {

	
AlumnoService alumnoServicio = new AlumnoService();
	
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getRequestDispatcher("WEB-INF/views/add-alumno.jsp").forward(request, response);
	
	}


	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		String nombre = request.getParameter("nombre");
		String dni = request.getParameter("dni");
		int edad = Integer.parseInt(request.getParameter("edad"));
		String modulo = request.getParameter("modulo");
		int curso = Integer.parseInt(request.getParameter("curso"));
		

		try {
			alumnoServicio.addAlumno(new Alumno(dni,nombre,edad,modulo,curso));
			response.sendRedirect("list-alumno.do");
		} catch(AlumnoDuplicadoException e) {
			request.setAttribute("errores", e.toString());
			request.getRequestDispatcher("/WEB-INF/views/add-alumno.jsp").forward(request, response);
		}
		
		
	
	


	}
	
}