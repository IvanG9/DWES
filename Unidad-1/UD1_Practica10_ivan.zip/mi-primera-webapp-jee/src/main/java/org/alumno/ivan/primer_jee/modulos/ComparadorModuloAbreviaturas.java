package org.alumno.ivan.primer_jee.modulos;


import java.util.Comparator;

public class ComparadorModuloAbreviaturas implements Comparator<Modulo>{
	@Override
	public int compare (Modulo a1, Modulo a2) {
				
			return a1.getAbreviatura().compareTo(a2.getAbreviatura());
		
	}
	
}	