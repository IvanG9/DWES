package org.alumno.ivan.primer_jee.modulos;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.modulos.ModuloService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/del-modulo.do")

public class DelModulos extends HttpServlet {

	ModuloService moduloServicio = new ModuloService();

	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		for(int i = 0; i < moduloServicio.listaModulos().size() ; i++){
			if(moduloServicio.listaModulos().get(i).getId() == Integer.parseInt(request.getParameter("modulo"))) {
				
				request.setAttribute("Id",moduloServicio.listaModulos().get(i).getId());
				request.setAttribute("Abreviatura",moduloServicio.listaModulos().get(i).getAbreviatura());
				request.setAttribute("Nombre",moduloServicio.listaModulos().get(i).getNombre());
				request.setAttribute("Horas",moduloServicio.listaModulos().get(i).getHoras());

			}
		}
		
		request.getRequestDispatcher("WEB-INF/views/del-modulo.jsp").forward(request, response);

	}
	

	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
				
		
		for(int i = 0; i < moduloServicio.listaModulos().size() ; i++){
			if(moduloServicio.listaModulos().get(i).getId() == Integer.parseInt(request.getParameter("modulo"))) {
				moduloServicio.delModulo(moduloServicio.listaModulos().get(i));
			}
		}
		
		response.sendRedirect("list-modulo.do");
		
		
	}
	}