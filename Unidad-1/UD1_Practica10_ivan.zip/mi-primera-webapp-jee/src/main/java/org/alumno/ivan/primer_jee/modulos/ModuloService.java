package org.alumno.ivan.primer_jee.modulos;

import java.util.ArrayList;

import java.util.Collection;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;

import org.alumno.ivan.primer_jee.login.*;

public class ModuloService {
	
	private static ArrayList <Modulo> modulos = new ArrayList <Modulo>(); 
	
		static{
			modulos.add(new Modulo(1,"Programacion",9,"DWES"));
			modulos.add(new Modulo(2,"Desarollo Web en Entorno Servidor",3,"PRO"));
			
		}
		
		public ArrayList<Modulo> listaModulos(){
			
			return modulos;
		}
		
		
		public ArrayList<Modulo>listaModulos(String orden){
			
			if(orden == null || orden == "") {
				orden = "nombre";
			}
			
			switch (orden) {
				case "id":
					Collections.sort(modulos);
		            break;
				case "nombre":
					Collections.sort(modulos,new ComparadorModuloNombre());
					break;
				case "horas":
					Collections.sort(modulos,new ComparadorModuloHoras());
					break;
				case "abreviaturas":
					Collections.sort(modulos,new ComparadorModuloAbreviaturas());
					break;
			}
			
		         return modulos;
			
		}
		
		
		public void addModulo(Modulo modulo) throws ModuloDuplicadoException{
			try {
				existeModulo(modulo);
				modulos.add(modulo);
			}catch(ModuloDuplicadoException e) {
				throw e;
			}
		}
		
		public void delModulo(Modulo modulo) {
			
			modulos.remove(modulo);
			
		}
		
		public boolean existeModulo(Modulo modulo) throws ModuloDuplicadoException{
			Modulo moduloExistente = encontrarModuloPorId(modulo.getId());
			if(moduloExistente!=null) {
				throw new ModuloDuplicadoException(moduloExistente, modulo);
			} else {
				return false;
			}
		}
		
		public Modulo encontrarModuloPorId(int id) {
			
			Modulo moduloDuplicado = null;
			for(int i=0; i < modulos.size(); i++) {
				if(modulos.get(i).getId() == (id)) {
					moduloDuplicado = modulos.get(i);
					break;
				}
			}
			return moduloDuplicado;
		}
		
		
}