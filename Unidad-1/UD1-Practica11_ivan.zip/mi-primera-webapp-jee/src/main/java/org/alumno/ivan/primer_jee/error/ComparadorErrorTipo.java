package org.alumno.ivan.primer_jee.error;

import java.util.Comparator;

import org.alumno.ivan.primer_jee.error.Error;


public class ComparadorErrorTipo implements Comparator<Error>{
	@Override
	public int compare (Error a1, Error a2) {

			return a1.getTipo().compareTo(a2.getTipo());
		
	}
}	