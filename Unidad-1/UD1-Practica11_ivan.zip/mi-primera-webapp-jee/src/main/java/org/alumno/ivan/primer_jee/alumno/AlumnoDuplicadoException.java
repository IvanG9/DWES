package org.alumno.ivan.primer_jee.alumno;

public class AlumnoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Alumno alumnoExistente;
	private Alumno alumnoNuevo;
	
	public AlumnoDuplicadoException(Alumno alumnoExistente, Alumno alumnoNuevo) {
		super();
		this.alumnoExistente = alumnoExistente;
		this.alumnoNuevo = alumnoNuevo;
	}

	@Override
	public String toString() {
		return "ERROR insertando Alumno: <br>"
				+ "Alumno existente:<br>"
				+ "dni: "+alumnoExistente.getDni()+"<br>"
				+ "nombre: "+alumnoExistente.getNombre()+"<br>"
				+ "Alumno nuevo: <br>"
				+ "dni: "+alumnoNuevo.getDni()+"<br>"
				+ "nombre: "+alumnoNuevo.getNombre();
	}
	
	
	
}