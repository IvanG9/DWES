package org.alumno.ivan.primer_jee.modulos;

import org.alumno.ivan.primer_jee.modulos.Modulo;

public class ModuloDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	private Modulo moduloExistente;
	private Modulo moduloNuevo;
	
	public ModuloDuplicadoException(Modulo moduloExistente, Modulo moduloNuevo) {
		super();
		this.moduloExistente = moduloExistente;
		this.moduloNuevo = moduloNuevo;
	}

	@Override
	public String toString() {
		return 
				"Modulo existente:<br>"
				+ "Id: "+moduloExistente.getId()+"<br>"
				+ "Nombre: "+moduloExistente.getNombre()+"<br>"
				+ "Modulo nuevo: <br>"
				+ "Id: "+moduloNuevo.getId()+"<br>"
				+ "Nombre: "+moduloNuevo.getNombre();
	}
	
	
	
}