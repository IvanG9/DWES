package org.alumno.ivan.primer_jee.error;

import java.util.ArrayList;
import java.util.Collections;

import org.alumno.ivan.primer_jee.error.Error;
import org.alumno.ivan.primer_jee.error.ComparadorErrorTipo;
import org.alumno.ivan.primer_jee.alumno.Alumno;
import org.alumno.ivan.primer_jee.alumno.AlumnoDuplicadoException;
import org.alumno.ivan.primer_jee.error.ComparadorErrorExplicacion;



public class ErrorService {
	
	
	private static ArrayList <Error> errores = new ArrayList <Error>(); 

	
	public ArrayList<Error> listaErrores(){
		
		return errores;
	}
	
	
	public ArrayList<Error>listaErrores(String orden){
		
		if(orden == null || orden == "") {
			orden = "nombre";
		}
		
		switch (orden) {
			case "id":
				Collections.sort(errores);
	            break;
			case "tipo":
				Collections.sort(errores,new ComparadorErrorTipo());
				break;
			case "explicacion":
				Collections.sort(errores,new ComparadorErrorExplicacion());
				break;
		
		}
		
	         return errores;
		
	}
	
	public void addError(Error error) throws AlumnoDuplicadoException{
		errores.add(error);
	}
	
	public void delError(Error error) {
		errores.remove(error);
	}
	

	
	
	
}
