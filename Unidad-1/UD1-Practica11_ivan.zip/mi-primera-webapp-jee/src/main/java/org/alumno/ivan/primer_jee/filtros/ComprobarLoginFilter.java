package org.alumno.ivan.primer_jee.filtros;
import java.io.IOException;


import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoDuplicadoException;
import org.alumno.ivan.primer_jee.error.Error;
import org.alumno.ivan.primer_jee.error.ErrorService;

@WebFilter(urlPatterns="*.do")

public class ComprobarLoginFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException{}
	
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request= (HttpServletRequest) servletRequest;
		System.out.println(request.getRequestURI());
		if (request.getSession().getAttribute("nombre") !=null) {
			chain.doFilter(request, servletResponse);
		}else {
			if(request.getRequestURI().contains("login.do")) {
				chain.doFilter(request, servletResponse);

			}else {
				HttpServletResponse response = (HttpServletResponse) servletResponse;
				ErrorService errorServicio = new ErrorService();
				String tipo = "Acceso Denegado";
				String explicacion = "Usuario anónimo ha intentando acceder a la web";
				try {
					errorServicio.addError(new Error(tipo,explicacion));
				} catch (AlumnoDuplicadoException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				response.sendRedirect("login.do");
			}
		}
		
	}
	
	@Override
	public void destroy() {}
}