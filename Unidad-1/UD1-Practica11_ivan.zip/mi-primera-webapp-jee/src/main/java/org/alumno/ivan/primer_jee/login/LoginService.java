package org.alumno.ivan.primer_jee.login;

import org.alumno.ivan.primer_jee.alumno.AlumnoDuplicadoException;
import org.alumno.ivan.primer_jee.error.Error;
import org.alumno.ivan.primer_jee.error.ErrorService;

public class LoginService {
	
	public boolean usuarioValido(String usuario, String password)  {
		
		if (usuario.contentEquals("ivan") && password.contentEquals("ivan")){
			
				return true;
			}else {
				ErrorService errorServicio = new ErrorService();
				String tipo = "Login incorrecto";
				String explicacion = "Login incorrecto de " + usuario;
				try {
					errorServicio.addError(new Error(tipo,explicacion));
				} catch (AlumnoDuplicadoException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		return false;
	}
}