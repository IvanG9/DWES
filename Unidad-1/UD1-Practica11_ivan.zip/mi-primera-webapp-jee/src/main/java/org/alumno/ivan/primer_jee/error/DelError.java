package org.alumno.ivan.primer_jee.error;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.error.ErrorService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/del-error.do")

public class DelError extends HttpServlet {

	ErrorService errorServicio = new ErrorService();

		@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		for(int i = 0; i < errorServicio.listaErrores().size() ; i++){
			if(errorServicio.listaErrores().get(i).getId() == Integer.parseInt(request.getParameter("id"))) {
				
				request.setAttribute("Id",errorServicio.listaErrores().get(i).getId());
				request.setAttribute("Tipo",errorServicio.listaErrores().get(i).getTipo());
				request.setAttribute("Explicacion",errorServicio.listaErrores().get(i).getExplicacion());

			}
		}
		
		request.getRequestDispatcher("WEB-INF/views/del-error.jsp").forward(request, response);
		
		
	}
			
		@Override
		protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
					
		
			for(int i = 0; i < errorServicio.listaErrores().size() ; i++){
				if(errorServicio.listaErrores().get(i).getId() == Integer.parseInt((request.getParameter("id")))) {
					errorServicio.delError(errorServicio.listaErrores().get(i));
				}
			}
			
		request.setAttribute("errores", errorServicio.listaErrores());	
		request.getRequestDispatcher("WEB-INF/views/list-errores.jsp").forward(request, response);
			
		}
		
	}
	