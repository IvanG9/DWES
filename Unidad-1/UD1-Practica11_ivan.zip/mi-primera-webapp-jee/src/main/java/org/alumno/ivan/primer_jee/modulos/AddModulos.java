package org.alumno.ivan.primer_jee.modulos;

import java.io.IOException;
import java.util.InputMismatchException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.modulos.ModuloService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/add-modulo.do")

public class AddModulos extends HttpServlet {

	
ModuloService moduloServicio = new ModuloService();
	
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getRequestDispatcher("WEB-INF/views/add-modulo.jsp").forward(request, response);
	
	}


	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		int id = 0;
		String nombre = "";
		int horas = 0;
		String abreviatura = "";
		String errors = "";
		
		try {
			try {
				id = Integer.parseInt(request.getParameter("id"));
			}catch (Exception e) {
				errors += "Identificador del módulo incorrecto. Debe de ser un numérico <br>";
			}
			try {
				horas = Integer.parseInt(request.getParameter("horas"));
			}catch (Exception e) {
				errors += "Horas del módulo incorrecto. Debe de ser un numérico <br>";
			}
			
			nombre = request.getParameter("nombre");
			if(nombre == "")
			errors += "No se permite que el nombre del módulo esté vacío <br>";
			if(nombre.length() < 5) 
			errors += "Nombre del módulo debe de contener al menos 5 caracteres <br>";				
			abreviatura = request.getParameter("abreviatura");
			if(horas < 2)
			errors += "Las horas debe de ser un valor igual o superior a 2 <br>";
			if (abreviatura == "")
			errors += "No se permite que la abreviatura esté vacía <br>";
			if (abreviatura.length() < 3)
			errors += "Nombre de la abreviatura debe de contener al menos 3 caracteres <br>";
			
			if(errors != "")
			throw new Exception(errors);
			
			try {
				moduloServicio.addModulo(new Modulo(id,nombre,horas,abreviatura));
				response.sendRedirect("list-modulo.do");
				
			} catch(ModuloDuplicadoException e) {
				request.setAttribute("errores", e.toString());
				request.setAttribute("modulos", moduloServicio.listaModulos());
				request.getRequestDispatcher("/WEB-INF/views/list-modulo.jsp").forward(request, response);

			}	

		}catch (Exception e) {
			request.setAttribute("errores", errors);
			request.setAttribute("modulos", moduloServicio.listaModulos());
			request.getRequestDispatcher("/WEB-INF/views/list-modulo.jsp").forward(request, response);
			
		}
	
	
	}
	
}