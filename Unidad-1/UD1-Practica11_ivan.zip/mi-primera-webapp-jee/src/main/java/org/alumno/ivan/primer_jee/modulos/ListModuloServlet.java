package org.alumno.ivan.primer_jee.modulos;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;
import org.alumno.ivan.primer_jee.login.LoginService;
import org.alumne.ivan.primer_jee.pagina.Pagina;

@WebServlet(urlPatterns = "/list-modulo.do")

public class ListModuloServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	ModuloService moduloServicio = new ModuloService();
	
	
	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
	request.getSession().setAttribute("pagina", new Pagina("modulos", "list-modulo.do"));
	request.setAttribute("modulos", moduloServicio.listaModulos(request.getParameter("orden")));
	request.getRequestDispatcher("WEB-INF/views/list-modulo.jsp").forward(request, response);
	
	}
	}