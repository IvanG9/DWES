package org.alumno.ivan.primer_jee.error;

import java.util.Comparator;

import org.alumno.ivan.primer_jee.error.Error;


public class ComparadorErrorExplicacion implements Comparator<Error>{
	@Override
	public int compare (Error a1, Error a2) {

			return a1.getExplicacion().compareTo(a2.getExplicacion());
		
	}
}	