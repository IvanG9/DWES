package org.alumno.ivan.primer_jee.error;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.alumne.ivan.primer_jee.pagina.Pagina;
import org.alumno.ivan.primer_jee.error.ErrorService;

@WebServlet(urlPatterns = "/list-error.do")

public class ListErrorServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	ErrorService ErrorServicio = new ErrorService();

	@Override
	protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
	
		
	request.getSession().setAttribute("pagina", new Pagina("error", "list-error.do"));
	request.setAttribute("errores", ErrorServicio.listaErrores(request.getParameter("orden")));
	request.getRequestDispatcher("WEB-INF/views/list-errores.jsp").forward(request, response);
	

	
	}
	}