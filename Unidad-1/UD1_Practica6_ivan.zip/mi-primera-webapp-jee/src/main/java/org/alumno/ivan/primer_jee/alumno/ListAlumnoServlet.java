package org.alumno.ivan.primer_jee.alumno;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/list-alumno.do")

public class ListAlumnoServlet extends HttpServlet {

	AlumnoService alumnoServicio = new AlumnoService();

	@Override
		protected void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		request.setAttribute("alumnos", alumnoServicio.listaAlumnos());
		/*request.setAttribute("nombre", request.getParameter("nombre"));*/
		alumnoServicio.delAlumnos(new Alumno(request.getParameter("alumno")));
		request.setAttribute("alumnos", alumnoServicio.listaAlumnos());
		request.getRequestDispatcher("WEB-INF/views/alumno.jsp").forward(request, response);
			
	}


	}