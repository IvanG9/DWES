package org.alumno.ivan.primer_jee.alumno;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alumno.ivan.primer_jee.alumno.AlumnoService;
import org.alumno.ivan.primer_jee.login.LoginService;


@WebServlet(urlPatterns = "/add-alumno.do")

public class AddAlumnoServlet extends HttpServlet {

	
AlumnoService alumnoServicio = new AlumnoService();
	
	@Override
	protected  void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

	alumnoServicio.addAlumnos(new Alumno(request.getParameter("nombre")));
	request.setAttribute("alumnos", alumnoServicio.listaAlumnos());
	response.sendRedirect("list-alumno.do");

	}
	
}