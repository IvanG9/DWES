package edu.alumno.ivan.api_rest_mysql_futbol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestMysqlFutbolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestMysqlFutbolApplication.class, args);
	}

}
