package edu.alumno.ivan.api_rest_mysql_futbol.security.enums;

public enum RolNombre {
    ROLE_ADMIN,ROLE_USER
}
