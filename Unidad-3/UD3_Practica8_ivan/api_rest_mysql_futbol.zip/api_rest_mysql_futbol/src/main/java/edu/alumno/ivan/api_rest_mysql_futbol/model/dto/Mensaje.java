package edu.alumno.ivan.api_rest_mysql_futbol.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Mensaje {
    private String mensaje;
}
