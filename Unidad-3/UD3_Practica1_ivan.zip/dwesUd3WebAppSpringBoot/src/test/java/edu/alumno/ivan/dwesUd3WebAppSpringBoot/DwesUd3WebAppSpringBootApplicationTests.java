package edu.alumno.ivan.dwesUd3WebAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DwesUd3WebAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
