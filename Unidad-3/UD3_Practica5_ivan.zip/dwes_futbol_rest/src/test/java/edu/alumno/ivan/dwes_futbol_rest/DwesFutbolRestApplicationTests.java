package edu.alumno.ivan.dwes_futbol_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DwesFutbolRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
