package edu.alumno.ivan.api_rest_mysql_futbol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestMysqlFutbolApplicationTests {

	@Test
	void contextLoads() {
	}

}
