package edu.alumno.ivan.dwes_primer_rest.service;

import java.util.List;
import java.util.Optional;

import edu.alumno.ivan.dwes_primer_rest.model.dto.AlumnoEdit;
import edu.alumno.ivan.dwes_primer_rest.model.dto.AlumnoInfo;
import edu.alumno.ivan.dwes_primer_rest.model.dto.AlumnoList;

public interface AlumnoService {

    public Optional<AlumnoEdit> getAlumnoEditByDni(String dni);
    public Optional<AlumnoInfo> getAlumnoInfoByDni(String dni);
    public AlumnoEdit save(AlumnoEdit alumnoEdit);
    public String deleteByDni(String dni);
    public Optional<AlumnoEdit> update(AlumnoEdit alumnoEdit);
    public List<AlumnoList> findAllAlumnoList();
    
}
