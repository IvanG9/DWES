package edu.alumno.ivan.dwes_primer_rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.alumno.ivan.dwes_primer_rest.model.db.AlumnoDb;

@Repository
public interface AlumnoRepository extends JpaRepository<AlumnoDb,String>{
    
}
