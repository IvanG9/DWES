package edu.alumno.ivan.dwes_primer_rest.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import edu.alumno.ivan.dwes_primer_rest.model.db.AlumnoDb;
import edu.alumno.ivan.dwes_primer_rest.model.dto.AlumnoEdit;
import edu.alumno.ivan.dwes_primer_rest.model.dto.AlumnoInfo;
import edu.alumno.ivan.dwes_primer_rest.model.dto.AlumnoList;
import edu.alumno.ivan.dwes_primer_rest.repository.AlumnoRepository;
import edu.alumno.ivan.dwes_primer_rest.service.AlumnoService;
import edu.alumno.ivan.dwes_primer_rest.service.mapper.AlumnoMapper;

@Service
public class AlumnoServiceImpl implements AlumnoService {

    private final AlumnoRepository alumnoRepository;

    @Autowired
    public AlumnoServiceImpl(AlumnoRepository alumnoRepository) {
        this.alumnoRepository = alumnoRepository;
    }

    @Override
    public Optional<AlumnoEdit> getAlumnoEditByDni(String dni) {
        Optional<AlumnoDb> alumnoDb = alumnoRepository.findById(dni);
        if (alumnoDb.isPresent())
            return Optional.of(AlumnoMapper.INSTANCE.alumnoDbToAlumnoEdit(alumnoDb.get()));
        else
            return Optional.empty();
    }

    @Override
    public Optional<AlumnoInfo> getAlumnoInfoByDni(String dni) {
        Optional<AlumnoDb> alumnoDb = alumnoRepository.findById(dni);
        if (alumnoDb.isPresent()) {
            return Optional.of(AlumnoMapper.INSTANCE.alumnoDbToAlumnoInfo(alumnoDb.get()));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public AlumnoEdit save(AlumnoEdit alumnoEdit) {
        AlumnoDb alumnoDb = alumnoRepository.save(AlumnoMapper.INSTANCE.alumnoEditToAlumnoDb(alumnoEdit));
        return AlumnoMapper.INSTANCE.alumnoDbToAlumnoEdit(alumnoDb);
    }

    @Override
    public String deleteByDni(String dni) {
        return alumnoRepository.findById(dni)
                .map(a -> {
                    alumnoRepository.deleteById(dni);
                    return "Deleted";
                }).orElse("Not Deleted");
    }

    @Override
    public Optional<AlumnoEdit> update(AlumnoEdit alumnoEdit) {
        Optional<AlumnoEdit> alumnoEditExistente = getAlumnoEditByDni(alumnoEdit.getDni());
        if (alumnoEditExistente.isPresent()) {
            deleteByDni(alumnoEdit.getDni());
            save(alumnoEdit);
            return getAlumnoEditByDni(alumnoEdit.getDni());
        } else {
            return Optional.empty();
        }
    }

    @Override
    public List<AlumnoList> findAllAlumnoList() {
        List<AlumnoDb> alumnosDb = alumnoRepository.findAll();
        return AlumnoMapper.INSTANCE.alumnosToAlumnosList(alumnosDb);
    }
}
