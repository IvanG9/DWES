package edu.alumno.ivan.dwes_ud3_primer_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DwesUd3PrimerJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
