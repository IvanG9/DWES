package org.profesor.joseramon.joseramon_primer_app_spring_mvc.model.dto;<--AQUI TU NOMBRE DE PAQUETE

import java.io.Serializable;


public class AlumnoList implements Serializable{
	private static final long serialVersionUID = 1L;
	private String dni;
	private String nombre;
	private Integer edad;
	private String ciclo;
	private Integer curso;
	private boolean erasmus=false;
	private String modificado;
	
	public AlumnoList() {
	}

	public String getErasmusChecked() {
		if (erasmus)
				return "checked";
		else
			return "";
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getEdad() {
		return edad;
	}

	public void setEdad(Integer edad) {
		this.edad = edad;
	}

	public String getCiclo() {
		return ciclo;
	}

	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}

	public Integer getCurso() {
		return curso;
	}

	public void setCurso(Integer curso) {
		this.curso = curso;
	}

	public boolean isErasmus() {
		return erasmus;
	}

	public void setErasmus(boolean erasmus) {
		this.erasmus = erasmus;
	}

	public String getModificado() {
		return modificado;
	}

	public void setModificado(String modificado) {
		this.modificado = modificado;
	}
	
}







