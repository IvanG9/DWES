package edu.profesor.joseramon.dwes_primer_rest.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import edu.profesor.joseramon.dwes_primer_rest.model.db.AlumnoDb;
import edu.profesor.joseramon.dwes_primer_rest.model.dto.AlumnoEdit;
import edu.profesor.joseramon.dwes_primer_rest.model.dto.AlumnoInfo;
import edu.profesor.joseramon.dwes_primer_rest.model.dto.AlumnoList;
import edu.profesor.joseramon.dwes_primer_rest.repository.AlumnoRepository;
import edu.profesor.joseramon.dwes_primer_rest.service.AlumnoService;
import edu.profesor.joseramon.dwes_primer_rest.service.mapper.AlumnoMapper;

@Service
public class AlumnoServiceImpl implements AlumnoService {

    private final AlumnoRepository alumnoRepository;

    @Autowired
    public AlumnoServiceImpl(AlumnoRepository alumnoRepository) {
        this.alumnoRepository = alumnoRepository;
    }

    @Override
    public Optional<AlumnoEdit> getAlumnoEditByDni(String dni) {
        Optional<AlumnoDb> alumnoDb=alumnoRepository.findById(dni);
        if (alumnoDb.isPresent())
            return Optional.of(AlumnoMapper.INSTANCE.alumnoDbToAlumnoEdit(alumnoDb.get()));
        else 
            return Optional.empty();
    }

    @Override
    public Optional<AlumnoInfo> getAlumnoInfoByDni(String dni) {
        return null;
    }

    @Override
    public AlumnoEdit save(AlumnoEdit alumnoEdit) {
        return null;
    }

    @Override
    public String deleteByDni(String dni) {
        return alumnoRepository.findById(dni)
        .map(a-> {
                alumnoRepository.deleteById(dni);
                return "Deleted";
            }).orElse("Not Deleted");
    }

    @Override
    public Optional<AlumnoEdit> update(AlumnoEdit alumnoEdit) {
         return null;
    }

    @Override
    public List<AlumnoList> findAllAlumnoList() {
         return null;
    }
}
