package edu.profesor.joseramon.dwes_primer_rest.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.profesor.joseramon.dwes_primer_rest.service.AlumnoService;
import edu.profesor.joseramon.dwes_primer_rest.model.dto.AlumnoEdit;
import edu.profesor.joseramon.dwes_primer_rest.model.dto.AlumnoInfo;
import edu.profesor.joseramon.dwes_primer_rest.model.dto.AlumnoList;
import edu.profesor.joseramon.dwes_primer_rest.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/api/v1/")
public class AlumnoRestController {

    private AlumnoService alumnoService;

    @Autowired
    public AlumnoRestController(AlumnoService alumnoService) {
        this.alumnoService=alumnoService;
    }

    @GetMapping("/alumnos")
    public List<AlumnoList> getAlumnosList() {
        return null;
    }

    @PostMapping("/alumnos")
    public AlumnoEdit newAlumnoEdit(@Valid @RequestBody AlumnoEdit alumnoEdit) {
        return alumnoService.save(alumnoEdit);
    }

    @GetMapping("/alumnos/{dni}")
    public ResponseEntity<AlumnoEdit> getAlumnoEditByDni(
    @PathVariable(value = "dni") String dni) throws RuntimeException {
        Optional<AlumnoEdit> alumnoEdit = alumnoService.getAlumnoEditByDni(dni);
        if (alumnoEdit.isPresent())
            return ResponseEntity.ok().body(alumnoEdit.get());
        else throw new ResourceNotFoundException("Alumno not found on :: "+ dni);
    }

    @GetMapping("/alumnos/{dni}/info")
    public ResponseEntity<AlumnoInfo> getAlumnoInfoByDni(
    @PathVariable(value = "dni") String dni) throws RuntimeException {
       return null;
    }
    
    @PutMapping("/alumnos/{dni}")
    public ResponseEntity<AlumnoEdit> updateAlumnoEdit(
    @PathVariable(value = "dni") String dni,
    @Valid @RequestBody AlumnoEdit alumnoEdit) throws RuntimeException {
    return null;
    }  
    
    @DeleteMapping("/alumnos/{dni}")
    public String deleteByDni(@PathVariable(value = "dni") String dni) {
        return "";
    } 
}

